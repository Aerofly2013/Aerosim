import { useEffect, useRef, useState } from 'react';
import { Activity, Gauge, RotateCcw, Satellite, ShieldAlert, Plane, ChevronUp, ChevronDown, MousePointer2 } from 'lucide-react';
import { FlightSim } from '@/flight/FlightSim';
import { AircraftType, defaultSettings } from '@/flight/types';
import Minimap from '@/Minimap';
import { AIRPORTS } from '@/flight/world';
import { Multiplayer } from '@/flight/Multiplayer';
import { validateName, MAX_NAME } from '@/flight/nameFilter';

interface Telemetry {
  throttle: number;
  airspeed: number;
  altitude: number;
  verticalSpeed: number;
  angleOfAttack: number;
  stalled: boolean;
  cameraMode: string;
  flaps: number;
  gearDown: boolean;
  gearExtension: number;
  speedbrake: number;
  reverseThrust: boolean;
  crashed: boolean;
  crashReason: string;
  showCrashOverlay: boolean;
  onGround: boolean;
  heading: number;
  bankAngle: number;
  pitchAngle: number;
  posX: number;
  posZ: number;
  yaw: number;
  kills: number;
  fighter: boolean;
  others: Array<{ id: string; name: string; x: number; z: number; yaw: number }>;
}

const initialTelemetry: Telemetry = {
  throttle: 0, airspeed: 0, altitude: 3.5, verticalSpeed: 0,
  angleOfAttack: 0, stalled: false, cameraMode: 'thirdPerson',
  flaps: 0, gearDown: true, gearExtension: 1, speedbrake: 0, reverseThrust: false, crashed: false, crashReason: '', showCrashOverlay: false, onGround: true,
  heading: 0, bankAngle: 0, pitchAngle: 0,
  posX: 0, posZ: 600, yaw: 0, kills: 0, fighter: false, others: [],
};

const FLAP_LABELS = ['UP', 'T/O', 'APPR', 'FULL'];

const AIRCRAFT_LABELS: Record<AircraftType, string> = {
  a350: 'A350',
  a380: 'A380',
  af1: 'AIR FORCE ONE',
  f16: 'FIGHTER JET',
};

export default function App() {
  const containerRef = useRef<HTMLDivElement>(null);
  const simRef = useRef<FlightSim | null>(null);
  const [started, setStarted] = useState(false);
  const [selectedAirport, setSelectedAirport] = useState(AIRPORTS[0].id);
  const [selectedAircraft, setSelectedAircraft] = useState<AircraftType>('a350');
  const [loading, setLoading] = useState(true);
  const [telemetry, setTelemetry] = useState<Telemetry>(initialTelemetry);
  const [mode, setMode] = useState<null | 'single' | 'multi'>(null);
  const [mp, setMp] = useState<Multiplayer | null>(null);
  const [username, setUsername] = useState(() => {
    try { return localStorage.getItem('aerosim-name') ?? ''; } catch { return ''; }
  });
  const [mpError, setMpError] = useState('');
  const [connecting, setConnecting] = useState(false);

  const startMulti = async () => {
    const check = validateName(username);
    if (!check.ok) { setMpError(check.error); return; }
    try { localStorage.setItem('aerosim-name', check.name); } catch { /* ignore */ }
    setMpError('');
    setConnecting(true);
    const m = new Multiplayer(check.name);
    try {
      await m.connect();
      setMp(m);
      setStarted(true);
    } catch (e) {
      m.dispose();
      setMpError(e instanceof Error ? e.message : 'Could not connect.');
    } finally {
      setConnecting(false);
    }
  };

  useEffect(() => {
    if (!started || !containerRef.current) return;
    const sim = new FlightSim(containerRef.current, defaultSettings(), selectedAirport, selectedAircraft, mp);
    simRef.current = sim;
    sim.onStateChange = (info) => setTelemetry(info);
    sim.start();
    setLoading(false);
    return () => { sim.dispose(); simRef.current = null; };
  }, [started, selectedAirport, selectedAircraft, mp]);

  // Ctrl+W (throttle down + pitch up) is a browser shortcut a page cannot block, but
  // while flying the browser will at least ask before closing the tab.
  useEffect(() => {
    if (!started) return;
    const warn = (e: BeforeUnloadEvent) => { e.preventDefault(); e.returnValue = ''; };
    window.addEventListener('beforeunload', warn);
    return () => window.removeEventListener('beforeunload', warn);
  }, [started]);

  const reset = () => simRef.current?.resetFlight();
  const aircraftLabel = AIRCRAFT_LABELS[selectedAircraft];

  const speedKnots = telemetry.airspeed * 1.944;
  const altitudeFeet = Math.max(0, telemetry.altitude * 3.281);
  const vsFpm = telemetry.verticalSpeed * 196.85;
  const cameraLabel = telemetry.cameraMode === 'thirdPerson' ? 'EXTERNAL' : telemetry.cameraMode === 'cockpit' ? 'COCKPIT' : 'GEAR CAM';

  return (
    <main className="sim-shell">
      <div ref={containerRef} className="sim-canvas" />

      {!started && mode === null && (
        <div className="home-screen">
          <div className="home-mark">AERO<span>SIM</span></div>
          <p className="home-tagline">FLIGHT SIMULATOR</p>
          <div className="mode-options">
            <button className="start-button" onClick={() => setMode('single')} autoFocus>SINGLE PLAYER</button>
            <button className="start-button" onClick={() => setMode('multi')}>MULTIPLAYER</button>
          </div>
        </div>
      )}

      {!started && mode !== null && (
        <div className="home-screen">
          <div className="home-mark">AERO<span>SIM</span></div>
          <p className="home-tagline">{aircraftLabel} FLIGHT SIMULATOR</p>

          <div className="plane-picker">
            <span className="airport-picker-label">SELECT AIRCRAFT</span>
            <div className="plane-options">
              <button
                className={`plane-option ${selectedAircraft === 'a350' ? 'selected' : ''}`}
                onClick={() => setSelectedAircraft('a350')}
              >
                <span className="plane-option-code">A350</span>
                <span className="plane-option-name">AIRBUS A350-900</span>
              </button>
              <button
                className={`plane-option ${selectedAircraft === 'a380' ? 'selected' : ''}`}
                onClick={() => setSelectedAircraft('a380')}
              >
                <span className="plane-option-code">A380</span>
                <span className="plane-option-name">AIRBUS A380-800</span>
              </button>
              <button
                className={`plane-option ${selectedAircraft === 'af1' ? 'selected' : ''}`}
                onClick={() => setSelectedAircraft('af1')}
              >
                <span className="plane-option-code">AIR FORCE ONE</span>
                <span className="plane-option-name">BOEING VC-25</span>
              </button>
              <button
                className={`plane-option ${selectedAircraft === 'f16' ? 'selected' : ''}`}
                onClick={() => setSelectedAircraft('f16')}
              >
                <span className="plane-option-code">FIGHTER JET</span>
                <span className="plane-option-name">MAX 500 KTS</span>
              </button>
            </div>
          </div>

          {mode === 'single' && (
          <div className="airport-picker">
            <span className="airport-picker-label">DEPARTING FROM</span>
            <div className="airport-options">
              {AIRPORTS.map((a) => (
                <button
                  key={a.id}
                  className={`airport-option ${selectedAirport === a.id ? 'selected' : ''}`}
                  onClick={() => setSelectedAirport(a.id)}
                >
                  {a.name}
                </button>
              ))}
            </div>
          </div>
          )}

          {mode === 'single' ? (
            <button className="start-button" onClick={() => setStarted(true)} autoFocus>
              START FLIGHT
            </button>
          ) : (
            <>
              <div className="airport-picker">
                <span className="airport-picker-label">CHOOSE A USERNAME</span>
                <input
                  className="airport-option selected"
                  placeholder="USERNAME"
                  maxLength={MAX_NAME}
                  value={username}
                  autoFocus
                  onChange={(e) => { setUsername(e.target.value); setMpError(''); }}
                  onKeyDown={(e) => { if (e.key === 'Enter' && !connecting) startMulti(); }}
                  style={{ width: 220, textAlign: 'center' }}
                />
              </div>
              <button className="start-button" disabled={connecting} onClick={startMulti}>
                {connecting ? 'CONNECTING...' : 'JOIN MULTIPLAYER'}
              </button>
              {mpError && <span style={{ color: '#ff8a80', fontSize: 12 }}>{mpError}</span>}
            </>
          )}
          <button className="airport-option" onClick={() => { setMode(null); setMpError(''); }}>BACK</button>
          <div className="home-controls">
            <div><b>W / S</b> or <b>&uarr; / &darr;</b><span>Pitch</span></div>
            <div><b>A / D</b> or <b>&larr; / &rarr;</b><span>Roll</span></div>
            <div><b>Q / E</b><span>Yaw</span></div>
            <div><b>Shift / Ctrl</b><span>Throttle up / down (Z also works)</span></div>
            <div><b>F / G</b><span>Flaps</span></div>
            <div><b>V</b><span>Gear</span></div>
            <div><b>B</b><span>Speed brakes</span></div>
            <div><b>Hold M</b><span>Reverse thrust</span></div>
            <div><b>N</b><span>Expand map</span></div>
            <div><b>C</b><span>Camera view</span></div>
            <div><b>R</b><span>Restart</span></div>
            <div><MousePointer2 size={13} /> Drag<span>Look around</span></div>
          </div>
        </div>
      )}

      {started && loading && (
        <div className="loading-screen">
          <div className="loading-mark">AERO<span>SIM</span></div>
          <div className="loading-line"><i /></div>
          <p>INITIALIZING FLIGHT SYSTEMS</p>
        </div>
      )}

      {started && telemetry.showCrashOverlay && (
        <div className="crash-overlay" role="alertdialog" aria-live="assertive">
          <div className="crash-card">
            <div className="crash-kicker"><ShieldAlert size={16} /> FLIGHT TERMINATED</div>
            <h1>YOU CRASHED!</h1>
            <p>{telemetry.crashReason}</p>
            <button className="restart-button" onClick={reset} autoFocus>
              <RotateCcw size={16} /> RESTART FLIGHT
            </button>
            <span className="crash-hint">or press <kbd>R</kbd></span>
          </div>
        </div>
      )}

      {started && (
      <div className="hud">
        {telemetry.fighter && !telemetry.crashed && (
          <>
            <div style={{ position: 'absolute', left: '50%', top: '42%', width: 26, height: 26, marginLeft: -13, marginTop: -13,
              border: '2px solid rgba(255,220,120,0.8)', borderRadius: '50%', pointerEvents: 'none' }}>
              <div style={{ position: 'absolute', left: 10, top: 10, width: 4, height: 4, borderRadius: '50%', background: 'rgba(255,220,120,0.95)' }} />
            </div>
            <div style={{ position: 'absolute', left: '50%', top: 70, transform: 'translateX(-50%)', pointerEvents: 'none',
              fontFamily: 'monospace', fontWeight: 700, letterSpacing: 2, color: '#ffd27a', textShadow: '0 0 6px rgba(0,0,0,0.8)' }}>
              KILLS {telemetry.kills}
            </div>
          </>
        )}
        {/* Top bar */}
        <header className="hud-header">
          <div className="brand">
            <div className="brand-mark"><Satellite size={16} /></div>
            <div>
              <strong>AEROSIM</strong>
              <span>{aircraftLabel} / {mp ? 'MULTIPLAYER' : 'FLIGHT 001'}</span>
            </div>
          </div>
          <div className="flight-status">
            <span className="status-dot" /> LIVE SIMULATION
            <b>HDG {telemetry.heading.toFixed(0).padStart(3, '0')}°</b>
          </div>
          <button className="reset-button" onClick={reset}>
            <RotateCcw size={14} /> RESET
          </button>
        </header>

        {/* Telemetry cards */}
        <section className="telemetry-row">
          <div className={`telemetry-card ${speedKnots < 60 && !telemetry.onGround ? 'amber' : 'cyan'}`}>
            <div className="card-label"><Gauge size={15} /> AIRSPEED</div>
            <div className="card-value">{speedKnots.toFixed(0)}<small>KTS</small></div>
          </div>

          <div className="telemetry-card white">
            <div className="card-label"><Activity size={15} /> ALTITUDE</div>
            <div className="card-value">{altitudeFeet.toFixed(0)}<small>FT</small></div>
          </div>

          <div className={`telemetry-card ${vsFpm < -600 ? 'amber' : 'white'}`}>
            <div className="card-label"><span className="vertical-icon">↕</span> V/S</div>
            <div className="card-value">{vsFpm >= 0 ? '+' : ''}{vsFpm.toFixed(0)}<small>FPM</small></div>
          </div>

          <div className="telemetry-card throttle-card">
            <div className="card-label">THROTTLE <span>{(telemetry.throttle * 100).toFixed(0)}%</span></div>
            <div className="throttle-track"><i style={{ width: `${telemetry.throttle * 100}%` }} /></div>
            <div className="throttle-scale"><span>IDLE</span><span>MAX</span></div>
          </div>
        </section>

        {/* Left panel — flight data */}
        <div className="left-panel glass-panel">
          <div className="panel-kicker">FLIGHT DATA</div>
          <div className="data-line"><span>PITCH</span><b>{telemetry.pitchAngle.toFixed(1)}°</b></div>
          <div className="data-line"><span>BANK</span><b>{telemetry.bankAngle.toFixed(1)}°</b></div>
          <div className="data-line"><span>AOA</span><b>{(telemetry.angleOfAttack * 57.3).toFixed(1)}°</b></div>
          <div className="data-line"><span>FLAPS</span><b className={telemetry.flaps > 0 ? 'active' : ''}>{FLAP_LABELS[telemetry.flaps]}</b></div>
          <div className="data-line"><span>SPD BRK</span><b className={telemetry.speedbrake > 0.02 ? 'active' : ''}>{telemetry.speedbrake >= 0.98 ? 'DEPLOYED' : telemetry.speedbrake <= 0.02 ? 'STOWED' : 'IN TRANSIT'}</b></div>
          <div className="data-line"><span>REV THR</span><b className={telemetry.reverseThrust ? 'active' : ''}>{telemetry.reverseThrust ? 'ACTIVE' : 'OFF'}</b></div>
          <div className="data-line"><span>GEAR</span><b className={telemetry.gearDown ? 'active' : ''}>{telemetry.gearDown ? 'DOWN' : 'UP'}</b></div>
          <div className="data-line"><span>SURFACE</span><b>{telemetry.onGround ? 'GROUND' : 'AIRBORNE'}</b></div>
        </div>

        {/* Right panel — attitude indicator */}
        <div className="right-panel glass-panel">
          <div className="panel-kicker">ATTITUDE</div>
          <div className="attitude-indicator">
            <div className="attitude-horizon" style={{
              transform: `rotate(${-telemetry.bankAngle}deg) translateY(${telemetry.pitchAngle * 2}px)`,
            }}>
              <div className="horizon-sky" />
              <div className="horizon-ground" />
              <div className="horizon-line" />
            </div>
            <div className="attitude-fixed">
              <div className="attitude-wings" />
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="bottom-row">
          <div className="controls glass-panel">
            <div className="panel-kicker">CONTROL INPUTS</div>
            <div className="control-grid">
              <span><kbd>W</kbd><kbd>S</kbd> PITCH</span>
              <span><kbd>A</kbd><kbd>D</kbd> ROLL</span>
              <span><kbd>Q</kbd><kbd>E</kbd> YAW</span>
              <span><kbd>SHIFT</kbd><kbd>CTRL</kbd> THROTTLE</span>
              <span><kbd>F</kbd> FLAPS DOWN</span>
              <span><kbd>G</kbd> FLAPS UP</span>
              <span><kbd>V</kbd> GEAR</span>
              <span><kbd>B</kbd> SPEED BRAKES</span>
              <span><kbd>M</kbd> REVERSE (HOLD)</span>
              <span><kbd>N</kbd> BIG MAP</span>
              {telemetry.fighter && <span><kbd>SPACE</kbd> FIRE GUNS</span>}
              <span><kbd>C</kbd> CAMERA</span>
              <span><kbd>R</kbd> RESET</span>
            </div>
          </div>

          <div className="status-stack">
            <div className={`camera-badge glass-panel ${telemetry.stalled ? 'warning' : ''}`}>
              {telemetry.stalled ? (
                <><ShieldAlert size={15} /> STALL WARNING</>
              ) : (
                <><span className="status-dot" /> {cameraLabel}</>
              )}
            </div>
            <div className="gear-badge glass-panel">
              <Plane size={14} />
              {telemetry.gearExtension >= 0.99 ? 'GEAR DOWN' : telemetry.gearExtension <= 0.01 ? 'GEAR UP' : 'GEAR IN TRANSIT'}
              <span className={`gear-status ${telemetry.gearDown ? 'down' : 'up'}`} />
            </div>
            <div className="flaps-badge glass-panel">
              FLAPS: {FLAP_LABELS[telemetry.flaps]}
              <div className="flaps-indicator">
                {[0, 1, 2, 3].map(i => (
                  <span key={i} className={`flap-dot ${i <= telemetry.flaps ? 'active' : ''}`} />
                ))}
              </div>
            </div>
          </div>
        </div>

        <Minimap x={telemetry.posX} z={telemetry.posZ} yaw={telemetry.yaw}
          onGround={telemetry.onGround} airspeed={telemetry.airspeed} others={telemetry.others} />

        {/* Center crosshair */}
        <div className="crosshair"><span /><span /></div>
      </div>
      )}
    </main>
  );
}
