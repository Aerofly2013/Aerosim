import { useEffect, useRef, useState } from 'react';
import {
  AIRPORTS, AirportDef, CITY, SEA_LEVEL, TERRAIN_CENTER_X, TERRAIN_CENTER_Z, TERRAIN_COLORS, TERRAIN_SEGMENTS,
  TERRAIN_SIZE, airportToWorld, terrainHeight,
} from '@/flight/world';

interface Props {
  x: number;
  z: number;
  yaw: number;
  onGround: boolean;
  airspeed: number;
  others?: Array<{ id: string; name: string; x: number; z: number; yaw: number }>;
}

const SIZE = 180;
const RANGE = 9000; // metres from the plane to the edge of the compact map
const BIG_MAX = 560; // largest the expanded chart gets, in px

/** The whole archipelago painted once onto an offscreen canvas (land in its terrain colours, shallows in teal). */
let chartCanvas: HTMLCanvasElement | null = null;
const CHART_PX = 512;

function getChart(): HTMLCanvasElement {
  if (chartCanvas) return chartCanvas;
  const canvas = document.createElement('canvas');
  canvas.width = CHART_PX;
  canvas.height = CHART_PX;
  const ctx = canvas.getContext('2d')!;
  const img = ctx.createImageData(CHART_PX, CHART_PX);
  const grid = TERRAIN_SEGMENTS + 1;
  for (let py = 0; py < CHART_PX; py++) {
    for (let px = 0; px < CHART_PX; px++) {
      const x = TERRAIN_CENTER_X - TERRAIN_SIZE / 2 + ((px + 0.5) / CHART_PX) * TERRAIN_SIZE;
      const z = TERRAIN_CENTER_Z - TERRAIN_SIZE / 2 + ((py + 0.5) / CHART_PX) * TERRAIN_SIZE;
      const h = terrainHeight(x, z);
      const o = (py * CHART_PX + px) * 4;
      if (h >= SEA_LEVEL) {
        const vx = Math.min(grid - 1, Math.round(((px + 0.5) / CHART_PX) * TERRAIN_SEGMENTS));
        const vy = Math.min(grid - 1, Math.round(((py + 0.5) / CHART_PX) * TERRAIN_SEGMENTS));
        const v = (vy * grid + vx) * 3;
        img.data[o] = TERRAIN_COLORS[v] * 215;
        img.data[o + 1] = TERRAIN_COLORS[v + 1] * 215;
        img.data[o + 2] = TERRAIN_COLORS[v + 2] * 215;
        img.data[o + 3] = 255;
      } else if (h > -14) {
        img.data[o] = 60; img.data[o + 1] = 150; img.data[o + 2] = 165; img.data[o + 3] = 110;
      }
    }
  }
  ctx.putImageData(img, 0, 0);
  chartCanvas = canvas;
  return canvas;
}

const wrap180 = (d: number) => ((d + 540) % 360) - 180;

export default function Minimap({ x, z, yaw, onGround, airspeed, others = [] }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [expanded, setExpanded] = useState(false);
  const [bigSize, setBigSize] = useState(BIG_MAX);

  // Expanded chart fits the window; M toggles it from the keyboard.
  useEffect(() => {
    const fit = () => setBigSize(Math.max(260, Math.min(BIG_MAX, window.innerWidth - 60, window.innerHeight - 220)));
    fit();
    window.addEventListener('resize', fit);
    const onKey = (e: KeyboardEvent) => { if (e.code === 'KeyN' && !e.repeat) setExpanded((v) => !v); };
    window.addEventListener('keydown', onKey);
    return () => { window.removeEventListener('resize', fit); window.removeEventListener('keydown', onKey); };
  }, []);
  const size = expanded ? bigSize : SIZE;
  const targetRef = useRef<AirportDef>(AIRPORTS[1]);

  // While parked, the destination is the nearest other airport (every island has one).
  if (onGround && airspeed < 3) {
    const others = AIRPORTS.filter((a) => Math.hypot(a.x - x, a.z - z) > 600);
    targetRef.current = others.reduce((near, a) =>
      Math.hypot(a.x - x, a.z - z) < Math.hypot(near.x - x, near.z - z) ? a : near, others[0] ?? AIRPORTS[0]);
  }
  const target = targetRef.current;

  const dx = target.x - x;
  const dz = target.z - z;
  const distance = Math.hypot(dx, dz);
  const bearing = (Math.atan2(dx, -dz) * 180) / Math.PI; // compass bearing to target
  const heading = (-yaw * 180) / Math.PI;                // compass heading of the plane
  const turn = wrap180(bearing - heading);
  const guidance = Math.abs(turn) < 8 ? 'ON COURSE' : `TURN ${turn > 0 ? 'RIGHT' : 'LEFT'} ${Math.abs(turn).toFixed(0)}°`;

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    if (canvas.width !== Math.round(size * dpr)) {
      canvas.width = Math.round(size * dpr);
      canvas.height = Math.round(size * dpr);
    }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const c = size / 2;
    // Compact: plane-centred radar. Expanded: the whole archipelago, with the plane moving across it.
    const viewX = expanded ? TERRAIN_CENTER_X : x;
    const viewZ = expanded ? TERRAIN_CENTER_Z : z;
    const scale = expanded ? size / TERRAIN_SIZE : c / RANGE;
    const toMap = (wx: number, wz: number): [number, number] => [c + (wx - viewX) * scale, c + (wz - viewZ) * scale];
    const edge = expanded ? Infinity : c; // airports further than this from the centre are "off the map"

    ctx.clearRect(0, 0, size, size);
    ctx.save();
    ctx.beginPath();
    if (expanded) ctx.roundRect(1, 1, size - 2, size - 2, 14);
    else ctx.arc(c, c, c - 1, 0, Math.PI * 2);
    ctx.clip();
    ctx.fillStyle = '#0a2230';
    ctx.fillRect(0, 0, size, size);

    // The islands themselves
    const [ox, oy] = toMap(TERRAIN_CENTER_X - TERRAIN_SIZE / 2, TERRAIN_CENTER_Z - TERRAIN_SIZE / 2);
    ctx.imageSmoothingEnabled = true;
    ctx.drawImage(getChart(), ox, oy, TERRAIN_SIZE * scale, TERRAIN_SIZE * scale);

    // Range rings + crosshair (radar only), or a 5 km grid on the big chart
    ctx.strokeStyle = 'rgba(120,190,200,.22)';
    ctx.lineWidth = 1;
    const [px0, py0] = toMap(x, z); // the aircraft on the map
    if (expanded) {
      ctx.beginPath();
      for (let g = Math.ceil((TERRAIN_CENTER_X - TERRAIN_SIZE / 2) / 5000) * 5000; g < TERRAIN_CENTER_X + TERRAIN_SIZE / 2; g += 5000) {
        const [gx] = toMap(g, 0); ctx.moveTo(gx, 0); ctx.lineTo(gx, size);
      }
      for (let g = Math.ceil((TERRAIN_CENTER_Z - TERRAIN_SIZE / 2) / 5000) * 5000; g < TERRAIN_CENTER_Z + TERRAIN_SIZE / 2; g += 5000) {
        const [, gy] = toMap(0, g); ctx.moveTo(0, gy); ctx.lineTo(size, gy);
      }
      ctx.stroke();
    } else {
      for (const r of [RANGE / 3, (RANGE * 2) / 3]) {
        ctx.beginPath();
        ctx.arc(c, c, r * scale, 0, Math.PI * 2);
        ctx.stroke();
      }
      ctx.beginPath();
      ctx.moveTo(c, 0); ctx.lineTo(c, size);
      ctx.moveTo(0, c); ctx.lineTo(size, c);
      ctx.stroke();
    }

    // Line to the destination
    const [tx, ty] = toMap(target.x, target.z);
    ctx.strokeStyle = 'rgba(88,224,223,.75)';
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.moveTo(px0, py0);
    ctx.lineTo(tx, ty);
    ctx.stroke();
    ctx.setLineDash([]);

    // City
    const [cx, cy] = toMap(CITY.x, CITY.z);
    if (expanded || Math.hypot(cx - c, cy - c) < c) {
      ctx.fillStyle = 'rgba(200,170,110,.35)';
      ctx.beginPath();
      ctx.arc(cx, cy, CITY.radius * scale, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = 'rgba(235,210,160,.9)';
      ctx.font = "600 9px 'JetBrains Mono', monospace";
      ctx.textAlign = 'center';
      ctx.fillText(CITY.name, cx, cy - CITY.radius * scale - 6);
    }

    // Airports
    ctx.font = `600 ${expanded ? 11 : 10}px 'JetBrains Mono', monospace`;
    ctx.textAlign = expanded ? 'left' : 'center';
    ctx.textBaseline = 'middle';
    for (const a of AIRPORTS) {
      const isTarget = a === target;
      const [ax, ay] = toMap(a.x, a.z);
      const inside = expanded || Math.hypot(ax - c, ay - c) < edge - 12;
      if (inside) {
        const [x1, y1] = toMap(...airportToWorld(a, 0, -a.runwayLength / 2));
        const [x2, y2] = toMap(...airportToWorld(a, 0, a.runwayLength / 2));
        ctx.strokeStyle = isTarget ? '#58e0df' : '#c5dbdc';
        ctx.lineWidth = 3;
        ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
        if (isTarget) {
          ctx.lineWidth = 1.5;
          ctx.beginPath(); ctx.arc(ax, ay, 14, 0, Math.PI * 2); ctx.stroke();
        }
        ctx.fillStyle = isTarget ? '#58e0df' : '#c5dbdc';
        ctx.fillText(expanded ? a.name : a.id, ax + (expanded ? 10 : 11), ay - (expanded ? 8 : 11));
      } else if (isTarget) {
        // Off the map: point at it from the edge
        const ang = Math.atan2(ty - c, tx - c);
        const ex = c + Math.cos(ang) * (c - 12);
        const ey = c + Math.sin(ang) * (c - 12);
        ctx.save();
        ctx.translate(ex, ey);
        ctx.rotate(ang);
        ctx.fillStyle = '#58e0df';
        ctx.beginPath(); ctx.moveTo(8, 0); ctx.lineTo(-6, -6); ctx.lineTo(-6, 6); ctx.closePath(); ctx.fill();
        ctx.restore();
      }
    }
    // Other players: orange arrows along their heading. On the compact radar, anyone beyond
    // the rim is shown as a small dot pinned to the edge in their direction.
    for (const o of others) {
      let [ox2, oy2] = toMap(o.x, o.z);
      const d = Math.hypot(ox2 - c, oy2 - c);
      const beyond = !expanded && d > c - 8;
      if (beyond) {
        const k = (c - 8) / d;
        ox2 = c + (ox2 - c) * k;
        oy2 = c + (oy2 - c) * k;
      }
      ctx.save();
      ctx.translate(ox2, oy2);
      if (beyond) {
        ctx.fillStyle = 'rgba(255,152,60,.8)';
        ctx.beginPath(); ctx.arc(0, 0, 3, 0, Math.PI * 2); ctx.fill();
      } else {
        ctx.rotate(-o.yaw);
        ctx.fillStyle = '#ff983c';
        ctx.strokeStyle = '#04141c';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(0, -7); ctx.lineTo(5, 6); ctx.lineTo(0, 3); ctx.lineTo(-5, 6); ctx.closePath();
        ctx.stroke(); ctx.fill();
      }
      ctx.restore();
      if (expanded && o.name) {
        ctx.font = "600 10px 'JetBrains Mono', monospace";
        ctx.textAlign = 'left';
        ctx.textBaseline = 'middle';
        ctx.fillStyle = '#ffc48a';
        ctx.fillText(o.name, ox2 + 9, oy2 + 1);
      }
    }
    ctx.restore();

    // North marker
    ctx.fillStyle = 'rgba(238,247,247,.75)';
    ctx.font = "600 9px 'JetBrains Mono', monospace";
    ctx.textAlign = 'center';
    ctx.fillText('N', c, 12);

    // The aircraft, pointing along its heading (centre of the radar, or wherever it is on the big chart)
    ctx.save();
    ctx.translate(px0, py0);
    ctx.rotate(-yaw);
    ctx.fillStyle = '#ffffff';
    ctx.strokeStyle = '#04141c';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(0, -9); ctx.lineTo(6.5, 8); ctx.lineTo(0, 4); ctx.lineTo(-6.5, 8); ctx.closePath();
    ctx.stroke(); ctx.fill();
    ctx.restore();
  }, [x, z, yaw, target, expanded, size, others]);

  return (
    <div className={`minimap glass-panel${expanded ? ' expanded' : ''}`} style={expanded ? { width: size + 22 } : undefined}>
      <button type="button" className="minimap-toggle" onClick={() => setExpanded((v) => !v)}
        title={expanded ? 'Shrink map (M)' : 'Expand map (M)'} aria-label={expanded ? 'Shrink map' : 'Expand map'}>
        {expanded ? '✕' : '⤢'}
      </button>
      <div className="panel-kicker">NAVIGATION{expanded ? ' · CHART' : ''}</div>
      <canvas ref={canvasRef} width={size} height={size} style={{ width: size, height: size, cursor: 'pointer' }}
        className={expanded ? 'big' : undefined} onClick={() => setExpanded((v) => !v)} />
      <div className="minimap-dest">
        <span>{target.name}</span>
        <b>{(distance / 1000).toFixed(1)} KM</b>
      </div>
      <div className="minimap-turn">{guidance}</div>
    </div>
  );
}
