import * as THREE from 'three';
import { AircraftState, AircraftType, InputState, defaultAircraftState, FLAP_SETTINGS } from './types';
import { HitKind, WorldHit, createHit, queryWorld } from './collision';
import { isWater } from './world';
import { Hull, hullFor } from './hull';

/** Wraps an angle (radians) into (-PI, PI], keeping accumulated Euler angles bounded forever. */
function wrapAngle(a: number): number {
  return THREE.MathUtils.euclideanModulo(a + Math.PI, Math.PI * 2) - Math.PI;
}

/**
 * Lightweight aerodynamic flight model, calibrated to a large twin-engine airliner.
 *
 * Speeds are metres/second internally and displayed as knots. Stall is ~118 KIAS
 * clean (falling to ~86 with full flaps), rotation is 116-140 KIAS, thrust gives
 * ~0.3 m/s^2 per 0.1 throttle at low speed (about 0.3 g takeoff acceleration),
 * level full-power speed is ~ 250 m/s (~490 kt), and climbing or descending
 * trades speed for height through gravity. Control rates are airliner-like:
 * a few degrees per second in pitch, ~10 deg/s in roll, and turns follow
 * g * tan(bank) / speed, so a 30 deg bank at approach speed turns ~3 deg/s.
 */
export class AircraftController {
  state: AircraftState;
  private group: THREE.Group;

  private readonly GRAVITY = 9.81;
  private readonly MAX_THROTTLE = 1.0;
  private readonly THROTTLE_RATE = 0.35;
  // Fighter Jet is limited to 500 kt; the airliners keep the original ceiling.
  private readonly MAX_AIRSPEED: number;
  private readonly MIN_AIRSPEED = 0;

  // 118 kt clean stall, progressively lower with flaps.
  private STALL_SPEED_KTS = [118, 104, 94, 86];
  private STALL_SPEED = this.STALL_SPEED_KTS.map((kts) => kts / 1.94384);
  private STALL_AOA = THREE.MathUtils.degToRad(16);
  private ROTATION_RATE = 0.11;
  // Handling envelope. Airliners are sluggish and limited; the fighter is agile.
  private rollGain = 1.8;          // roll rate relative to ROTATION_RATE
  private controlResponse = 4;     // how quickly the surfaces follow the keys
  private maxBank = 1.05;          // rad
  private pitchMin = -0.42;        // rad
  private pitchMax = 0.5;          // rad
  private thrustMax = 3.4;         // m/s^2 at full throttle, low speed
  private yawAuthority = 0.3; // rad/s of pitch at full stick, ~6 deg/s
  private readonly GROUND_ROLL_FRICTION = 0.25;
  private readonly BRAKE_FORCE = 0.8;
  private readonly STALL_CRASH_DELAY = 1.25;
  private TAKEOFF_ROTATION_KTS = [140, 130, 122, 116];
  private TAKEOFF_ACCEL = 3.1; // m/s^2 — realistic takeoff-roll acceleration (~0.3g)

  private stallTimer = 0;
  private crashed = false;
  private wasAirborne = false;
  private airborneSink = 0; // descent rate (m/s) on the last frame before reaching the runway
  private impactFired = false;
  // Set when the aircraft has hit a solid obstacle: the wreck stays where it
  // struck instead of continuing to fall through the building or mountain.
  private frozen = false;
  // Shot down: tumbles and dives hard instead of gliding gently to the ground.
  private shotDown = false;

  // Airframe collision against buildings, mountains and hills.
  private hull: Hull;
  private prevPos = new THREE.Vector3();
  private prevQuat = new THREE.Quaternion();
  private nextQuat = new THREE.Quaternion();
  private sweepPos = new THREE.Vector3();
  private sweepQuat = new THREE.Quaternion();
  private probe = new THREE.Vector3();
  private hit: WorldHit = createHit();
  private scratchHit: WorldHit = createHit();

  private spawn?: { x: number; z: number; yaw: number };

  /**
   * Fired exactly once per crash, the frame the aircraft actually reaches the
   * ground — not the frame the crash was decided. A stall, for instance, is
   * triggered high in the air; the impact (and the explosion/debris it
   * produces) happens later, once gravity brings it down. Flying into a
   * building, mountain or hillside is different: the impact is immediate and
   * `surfaceNormal` points out of whatever was hit.
   */
  onImpact?: (position: THREE.Vector3, rotation: THREE.Euler, velocity: THREE.Vector3, surfaceNormal?: THREE.Vector3) => void;

  constructor(group: THREE.Group, spawn?: { x: number; z: number; yaw: number }, aircraftType: AircraftType = 'a350') {
    this.group = group;
    this.spawn = spawn;
    this.state = defaultAircraftState(spawn);
    this.hull = hullFor(aircraftType);
    this.MAX_AIRSPEED = aircraftType === 'f16' ? 500 / 1.94384 : 270;
    if (aircraftType === 'f16') {
      // Fighter: light, powerful and highly manoeuvrable.
      this.STALL_SPEED_KTS = [100, 92, 86, 80];
      this.STALL_SPEED = this.STALL_SPEED_KTS.map((kts) => kts / 1.94384);
      this.STALL_AOA = THREE.MathUtils.degToRad(28);
      this.ROTATION_RATE = 0.5;      // ~29 deg/s pitch at full stick
      this.rollGain = 3.2;           // ~90 deg/s roll
      this.controlResponse = 9;      // snappy stick response
      this.maxBank = 1.45;           // ~83 deg of bank
      this.pitchMin = -0.9;
      this.pitchMax = 1.1;
      this.thrustMax = 7;            // thrust-to-weight well above an airliner
      this.yawAuthority = 0.6;
      this.TAKEOFF_ROTATION_KTS = [125, 118, 112, 106];
      this.TAKEOFF_ACCEL = 6.5;
    }
  }

  /** Changes where the next reset() spawns the aircraft (used when the airport picker changes). */
  setSpawn(spawn: { x: number; z: number; yaw: number }): void {
    this.spawn = spawn;
  }

  reset(): void {
    this.state = defaultAircraftState(this.spawn);
    this.stallTimer = 0;
    this.crashed = false;
    this.wasAirborne = false;
    this.airborneSink = 0;
    this.impactFired = false;
    this.frozen = false;
    this.shotDown = false;
    this.syncTransform();
  }

  syncTransform(): void {
    this.group.position.copy(this.state.position);
    this.group.rotation.copy(this.state.rotation);
  }

  update(input: InputState, dt: number): void {
    if (this.crashed) {
      this.updateCrash(dt);
      return;
    }

    // Pose at the start of the frame, so the sweep for obstacles has a known-clear starting point.
    this.prevPos.copy(this.state.position);
    this.prevQuat.setFromEuler(this.state.rotation);

    // Throttle
    if (input.throttleUp) {
      this.state.throttle = Math.min(this.MAX_THROTTLE, this.state.throttle + this.THROTTLE_RATE * dt);
    }
    if (input.throttleDown) {
      this.state.throttle = Math.max(0, this.state.throttle - this.THROTTLE_RATE * dt);
    }

    // Control inputs
    const pitchInput = Number(input.pitchUp) - Number(input.pitchDown);
    const rollInput = Number(input.rollLeft) - Number(input.rollRight);
    const yawInput = Number(input.yawLeft) - Number(input.yawRight);

    this.state.pitch = THREE.MathUtils.damp(this.state.pitch, pitchInput, this.controlResponse, dt);
    this.state.roll = THREE.MathUtils.damp(this.state.roll, rollInput, this.controlResponse, dt);
    this.state.yaw = THREE.MathUtils.damp(this.state.yaw, yawInput, this.controlResponse, dt);

    const flapDeg = FLAP_SETTINGS[this.state.flaps];
    const flapFraction = this.state.flaps / 3;
    const flapLiftBoost = 1 + flapFraction * 0.65;
    const flapDragBoost = 1 + flapFraction * 1.2;

    const gearDrag = 1 + 0.6 * this.state.gearExtension;
    const sb = this.state.speedbrakeExtension; // 0..1 speed brake / spoiler deployment
    const speed = Math.max(0, this.state.airspeed);
    const speedFactor = Math.min(1, (speed / 65) ** 2); // control surfaces need airflow
    const rotRate = this.ROTATION_RATE * Math.max(0.2, speedFactor);

    // Apply rotations. Less control authority at very low airspeed.
    this.state.rotation.x += this.state.pitch * rotRate * dt;
    this.state.rotation.z += this.state.roll * rotRate * this.rollGain * dt;
    // Coordinated turn: heading rate = g * tan(bank) / airspeed (rudder only adds a little).
    const turnRate = speed > 30 ? (this.GRAVITY * Math.tan(this.state.rotation.z)) / speed : 0;
    this.state.rotation.y += (this.state.yaw * rotRate * this.yawAuthority + turnRate * (this.state.onGround ? 0 : 1)) * dt;

    // Airliner limits: no loops or barrel rolls.
    this.state.rotation.x = THREE.MathUtils.clamp(this.state.rotation.x, this.pitchMin, this.pitchMax);
    this.state.rotation.z = THREE.MathUtils.clamp(this.state.rotation.z, -this.maxBank, this.maxBank);

    const forward = this.getForwardVector();
    
    // Approximate angle of attack from pitch attitude versus vertical flight path.
    const flightPathAngle = Math.atan2(this.state.velocity.y, Math.max(speed, 8));
    this.state.angleOfAttack = THREE.MathUtils.clamp(
      this.state.rotation.x - flightPathAngle,
      -0.6,
      0.6,
    );

    const stallSpeed = this.STALL_SPEED[this.state.flaps];

    // The flight path is not the nose direction: at slow approach speeds the wing needs a
    // few degrees of angle of attack just to hold the aircraft up, so the nose sits ABOVE
    // the path. This keeps the nose level/slightly up while descending on final instead of
    // forcing it to point down at the runway. (Negligible at cruise speed.)
    const aoaTrim = THREE.MathUtils.clamp(
      0.14 * (stallSpeed / Math.max(speed, stallSpeed * 0.8)) ** 2, 0.02, 0.15);
    const pathDir = forward.clone()
      .applyAxisAngle(new THREE.Vector3().crossVectors(forward, new THREE.Vector3(0, 1, 0)).normalize(), -aoaTrim);
    const aerodynamicStall = speed < stallSpeed || this.state.angleOfAttack > this.STALL_AOA;
    const airborne = !this.state.onGround && this.state.position.y > 3.6;

    this.state.stalled = airborne && aerodynamicStall;

    // Thrust rises with throttle, while drag grows strongly with speed.
    // Engines lose thrust as airspeed rises; drag grows with the square of speed.
    // Reverse thrust (hold M): works on the ground and in the air. Thrust points forward-to-back, strongest
    // at landing speed and fading to nothing near walking pace so the aircraft never reverses.
    const reversing = input.reverseThrust && speed > 1;
    this.state.reverseThrust = reversing;
    const thrust = reversing
      ? -(0.35 + 0.65 * this.state.throttle) * 2.6 * Math.min(1, speed / 15)
      : this.state.throttle * this.thrustMax * Math.max(0, 1 - speed / 400);
    const parasiteDrag = 0.0000204 * speed * speed * flapDragBoost * gearDrag * (1 + 2.4 * sb);
    const inducedDrag = speed > 20 ? 120 / (speed * speed) * (1 + Math.abs(this.state.angleOfAttack) * 4) : 0.3;
    // Gravity along the flight path: climbing bleeds speed, diving gains it.
    const pathGravity = airborne ? -this.GRAVITY * pathDir.y : 0;
    let drag = parasiteDrag + inducedDrag - pathGravity + (this.state.onGround ? 0.12 : 0);
    // Spoilers on the ground dump lift onto the wheels and add real stopping power.
    if (this.state.onGround) drag += sb * Math.min(1, speed / 40) * 1.1;

    // A real airliner accelerates down the runway at roughly 0.3g, not the
    // thrust-to-drag ratio it can pull once airborne — cap the ground roll to
    // a true-to-life acceleration so takeoff takes a realistic amount of runway.
    if (this.state.onGround) {
      const uncappedAccel = thrust - drag;
      if (uncappedAccel > this.TAKEOFF_ACCEL) drag += uncappedAccel - this.TAKEOFF_ACCEL;
    }

    // Lift curve: approximately linear below the critical AOA, then collapses after stall.
    const absAoA = Math.abs(this.state.angleOfAttack);
    const preStallLift = Math.max(0, 1.05 - absAoA / this.STALL_AOA);
    const stallLiftFactor = this.state.stalled
      ? Math.max(0.05, 0.18 - Math.max(0, this.state.angleOfAttack - this.STALL_AOA) * 1.5)
      : preStallLift;
    // Deployed speed brakes spoil some lift, so the aircraft sinks faster for the same attitude.
    const liftAccel = this.GRAVITY * (speed / Math.max(30, stallSpeed)) ** 2 * stallLiftFactor * (1 - 0.3 * sb);

    // Longitudinal acceleration.
    const accel = thrust - drag;
    this.state.airspeed = THREE.MathUtils.clamp(
      speed + accel * dt,
      this.MIN_AIRSPEED,
      this.MAX_AIRSPEED,
    );

    // Ground effect: cushions the last few metres before touchdown so a
    // steady approach naturally settles into a smooth landing.
    const groundY = 3.5;
    const heightAGL = this.state.position.y - groundY;
    const groundEffect = airborne ? THREE.MathUtils.clamp(1 - heightAGL / 14, 0, 1) : 0;

    // Desired velocity follows the aircraft nose, with lift and gravity acting vertically.
    const desiredVel = pathDir.clone().multiplyScalar(this.state.airspeed);
    desiredVel.y -= Math.max(0, this.GRAVITY - liftAccel) * dt * 3; // too slow to hold the aircraft up
    if (groundEffect > 0) desiredVel.y += groundEffect * 3.2 * dt; // gentle cushion of lift near the ground

    // Ground handling and takeoff behaviour.
    this.state.onGround = this.state.position.y <= groundY + 0.5;

    if (this.state.onGround) {
      this.stallTimer = 0;

      // Keep wings stable while rolling, but allow rotation once moving quickly enough.
      this.state.rotation.z = THREE.MathUtils.damp(this.state.rotation.z, 0, 6, dt);
      const rotationSpeed = this.TAKEOFF_ROTATION_KTS[this.state.flaps] / 1.94384;
      if (speed < rotationSpeed) {
        this.state.rotation.x = THREE.MathUtils.damp(this.state.rotation.x, 0, 5, dt);
      }

      if (this.state.throttle < 0.1) {
        this.state.airspeed = Math.max(0, this.state.airspeed - (this.GROUND_ROLL_FRICTION + this.BRAKE_FORCE * 0.15) * dt * 5);
      }

      this.state.rotation.y += this.state.yaw * 0.3 * dt * Math.min(1, this.state.airspeed / 10);

      // The lift formula above depends on speed, not on being physically
      // rotated — without this, enough ground speed alone could loft the
      // aircraft off the runway at a level attitude, producing an erratic
      // bounce. Require an actual nose-up attitude before allowing any climb.
      if (this.state.rotation.x < 0.02) desiredVel.y = Math.min(desiredVel.y, 0);
      desiredVel.y = Math.max(desiredVel.y, -0.25);
    }

    // A stall in the air becomes an uncontrolled descent/crash if not recovered promptly.
    if (this.state.stalled && airborne) {
      this.stallTimer += dt;
      // Reduce lift and pitch the nose down as the wing loses lift.
      desiredVel.y -= (8 + (this.stallTimer * 5));
      this.state.rotation.x = THREE.MathUtils.damp(this.state.rotation.x, -0.5, 1.5, dt);
      this.state.airspeed = Math.max(0, this.state.airspeed - 5 * dt);

      if (this.stallTimer >= this.STALL_CRASH_DELAY) {
        this.triggerCrash('The aircraft stalled and fell out of the sky.');
      }
    } else {
      this.stallTimer = Math.max(0, this.stallTimer - dt * 2);
    }

    this.state.velocity.lerp(desiredVel, Math.min(1, dt * 2.6));
    this.state.verticalSpeed = this.state.velocity.y;
    this.state.position.addScaledVector(this.state.velocity, dt);

    // Wheels (or belly) reaching the sea: there is no runway out here.
    if (!this.crashed && this.state.position.y <= groundY + 0.35 &&
      isWater(this.state.position.x, this.state.position.z)) {
      this.ditch();
    }

    // Remember that we have been flying, and how fast we were sinking on the
    // final approach (the value from the last frame before the ground zone).
    if (this.state.position.y > groundY + 1) this.wasAirborne = true;
    if (this.state.position.y > groundY + 0.6) this.airborneSink = Math.max(0, -this.state.velocity.y);

    // Ground collision.
    if (this.state.position.y < groundY) {
      if (this.wasAirborne && !this.crashed) this.checkTouchdown();
      if (this.crashed && !this.impactFired) {
        this.impactFired = true;
        this.onImpact?.(this.state.position.clone(), this.state.rotation.clone(), this.state.velocity.clone());
      }
      this.wasAirborne = false;
      this.airborneSink = 0;
      this.state.position.y = groundY;
      if (this.state.velocity.y < 0) this.state.velocity.y = 0;
      this.state.onGround = true;
      if (this.crashed) {
        this.state.rotation.x = -0.8;
        this.state.rotation.z *= 0.95;
      }
    } else {
      this.state.onGround = false;
    }

    // Once settled on the ground, pin the aircraft exactly to the runway
    // height instead of leaving it to drift within the ground tolerance band
    // frame to frame — the source of the small visible "vibration" while
    // taxiing or holding on the runway.
    if (this.state.onGround && !this.crashed &&
      Math.abs(this.state.position.y - groundY) < 0.05 && this.state.velocity.y <= 0) {
      this.state.position.y = groundY;
      this.state.velocity.y = 0;
    }

    // Anything solid in the way? (A crash that was already decided this frame, e.g. a
    // hard touchdown, takes priority.)
    if (!this.crashed) this.collideWithWorld();

    // Keep the Euler angles wrapped to a small range. Left unbounded, heading
    // and bank keep growing over a long flight full of turns/rolls, which
    // eventually loses floating-point precision and shows up as jitter.
    this.state.rotation.y = wrapAngle(this.state.rotation.y);
    this.state.rotation.z = wrapAngle(this.state.rotation.z);

    this.state.heading = ((THREE.MathUtils.radToDeg(this.state.rotation.y) % 360) + 360) % 360;
    this.state.bankAngle = THREE.MathUtils.radToDeg(this.state.rotation.z);
    this.state.pitchAngle = THREE.MathUtils.radToDeg(this.state.rotation.x);

    this.syncTransform();
  }

  /** Brings the aircraft down from outside (e.g. shot by another player). */
  forceCrash(reason: string): void {
    if (this.crashed) return;
    this.triggerCrash(reason);
    this.shotDown = true;
    this.state.velocity.y = Math.min(this.state.velocity.y, -12);
  }

  private triggerCrash(reason: string): void {
    if (this.crashed) return;
    this.crashed = true;
    this.state.crashed = true;
    this.state.crashReason = reason;
    this.state.throttle = 0;
  }

  /** True if any probe point of the airframe, at the current sweep pose, is inside a solid. */
  private airframeHits(hit: WorldHit): boolean {
    const groups = this.state.gearExtension > 0.5 ? [this.hull.body, this.hull.gear] : [this.hull.body];
    for (const points of groups) {
      for (const local of points) {
        this.probe.copy(local).applyQuaternion(this.sweepQuat).add(this.sweepPos);
        if (queryWorld(this.probe.x, this.probe.y, this.probe.z, hit)) return true;
      }
    }
    return false;
  }

  private poseAt(t: number): void {
    this.sweepPos.lerpVectors(this.prevPos, this.state.position, t);
    this.sweepQuat.slerpQuaternions(this.prevQuat, this.nextQuat, t);
  }

  /**
   * Sweeps the airframe from where it was at the start of the frame to where
   * this frame's physics put it. If it passes through a building, mountain or
   * hillside, the aircraft is stopped at the moment of contact and crashes
   * there. Returns true if that happened.
   */
  private collideWithWorld(): boolean {
    const s = this.state;
    this.nextQuat.setFromEuler(s.rotation);

    // Check every few metres of travel so a fast aircraft can't skip over a wall.
    const steps = THREE.MathUtils.clamp(Math.ceil(this.prevPos.distanceTo(s.position) / 3), 1, 10);
    let firstHit = -1;
    for (let k = 1; k <= steps; k++) {
      this.poseAt(k / steps);
      if (this.airframeHits(this.hit)) { firstHit = k; break; }
    }
    if (firstHit < 0) return false;

    // Narrow down to the moment of first contact.
    let clear = (firstHit - 1) / steps;
    let touching = firstHit / steps;
    for (let i = 0; i < 6; i++) {
      const mid = (clear + touching) / 2;
      this.poseAt(mid);
      if (this.airframeHits(this.scratchHit)) touching = mid; else clear = mid;
    }
    this.poseAt(touching);
    this.airframeHits(this.hit); // what was hit, and the surface normal there
    this.poseAt(clear);
    s.position.copy(this.sweepPos);
    s.rotation.setFromQuaternion(this.sweepQuat, 'YXZ');

    this.crashIntoWorld(this.hit.kind, new THREE.Vector3(this.hit.nx, this.hit.ny, this.hit.nz));
    return true;
  }

  /** Immediate impact: explosion and wreckage at the point of contact, and the aircraft stays put. */
  private crashIntoWorld(kind: HitKind, normal: THREE.Vector3): void {
    const reasons: Record<HitKind, string> = {
      building: 'You flew into a building.',
      mountain: 'You flew into a mountain.',
      terrain: 'You flew into the hillside.',
    };
    // Keeps the original reason if the aircraft was already going down (e.g. a stall).
    this.triggerCrash(reasons[kind]);

    const s = this.state;
    const velocity = s.velocity.clone();
    this.frozen = true;
    this.impactFired = true;
    s.velocity.set(0, 0, 0);
    s.airspeed = 0;
    s.verticalSpeed = 0;
    s.onGround = false;
    this.onImpact?.(s.position.clone(), s.rotation.clone(), velocity, normal);
  }

  /** Down in the ocean: the aircraft stops dead and breaks up where it hit the water. */
  private ditch(): void {
    this.triggerCrash('You ditched in the ocean.');
    const s = this.state;
    const velocity = s.velocity.clone();
    this.frozen = true;
    this.impactFired = true;
    s.velocity.set(0, 0, 0);
    s.airspeed = 0;
    s.verticalSpeed = 0;
    s.onGround = false;
    this.onImpact?.(s.position.clone(), s.rotation.clone(), velocity, new THREE.Vector3(0, 1, 0));
  }

  /** Called on the frame the aircraft comes back down to the ground. */
  private checkTouchdown(): void {
    const s = this.state;
    if (s.gearExtension < 0.9) {
      this.triggerCrash('You landed with the landing gear up.');
    } else if (this.airborneSink > 16) {
      this.triggerCrash(`Hard landing: descent rate was ${Math.round(this.airborneSink * 196.85)} ft/min.`);
    } else if (s.rotation.x < -0.6 && s.airspeed > 20) {
      this.triggerCrash('You touched down nose-first.');
    } else if (Math.abs(s.rotation.z) > 0.7) {
      this.triggerCrash('A wingtip struck the ground.');
    }
  }

  private updateCrash(dt: number): void {
    // The wreck is down (it hit something solid): nothing left to simulate.
    if (this.frozen) {
      this.syncTransform();
      return;
    }

    this.prevPos.copy(this.state.position);
    this.prevQuat.setFromEuler(this.state.rotation);

    // Keep the aircraft moving forward while gravity pulls it down.
    const forward = this.getForwardVector();
    this.state.airspeed = Math.max(0, this.state.airspeed - 3 * dt);
    this.state.velocity.lerp(
      new THREE.Vector3(forward.x * this.state.airspeed, this.state.velocity.y - this.GRAVITY * 0.8 * dt, forward.z * this.state.airspeed),
      Math.min(1, dt * 1.8),
    );
    this.state.rotation.x = THREE.MathUtils.damp(this.state.rotation.x, -0.85, this.shotDown ? 1.6 : 0.9, dt);
    if (this.shotDown) {
      // Out of control: spin, and gravity takes over completely.
      this.state.rotation.z += 2.6 * dt;
      this.state.velocity.y -= this.GRAVITY * 1.2 * dt;
    }
    this.state.position.addScaledVector(this.state.velocity, dt);
    this.state.verticalSpeed = this.state.velocity.y;

    // A crashing aircraft can still plough into a building or mountain on the way down.
    const hitWorld = !this.impactFired && this.collideWithWorld();

    if (hitWorld) {
      // collideWithWorld() already fired the impact where it struck.
    } else if (this.state.position.y <= 3.5) {
      if (!this.impactFired) {
        this.impactFired = true;
        this.onImpact?.(this.state.position.clone(), this.state.rotation.clone(), this.state.velocity.clone());
      }
      this.state.position.y = 3.5;
      this.state.velocity.set(0, 0, 0);
      this.state.onGround = true;
    } else {
      this.state.onGround = false;
    }

    this.state.rotation.y = wrapAngle(this.state.rotation.y);
    this.state.rotation.z = wrapAngle(this.state.rotation.z);

    this.state.heading = ((THREE.MathUtils.radToDeg(this.state.rotation.y) % 360) + 360) % 360;
    this.state.bankAngle = THREE.MathUtils.radToDeg(this.state.rotation.z);
    this.state.pitchAngle = THREE.MathUtils.radToDeg(this.state.rotation.x);
    this.syncTransform();
  }

  getForwardVector(): THREE.Vector3 {
    return new THREE.Vector3(0, 0, -1).applyEuler(this.state.rotation);
  }

  getUpVector(): THREE.Vector3 {
    return new THREE.Vector3(0, 1, 0).applyEuler(this.state.rotation);
  }
}
