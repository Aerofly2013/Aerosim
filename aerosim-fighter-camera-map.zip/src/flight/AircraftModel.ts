import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { FBXLoader } from 'three/examples/jsm/loaders/FBXLoader.js';
import { unpackGlb } from './unpackGlb';
import { AircraftType } from './types';

const F16_LENGTH = 15;
const F16_GEAR_LEGS: Array<{ meshes: string[]; axis: 'x' | 'z'; angle: number; tuckedScale: number }> = [
  { meshes: ['FrontLandingGear', 'FrontWheel', 'NoseDoors'], axis: 'x', angle: Math.PI / 2, tuckedScale: 0.5 },
  { meshes: ['RearLandingGearL', 'RearWheelL'], axis: 'z', angle: THREE.MathUtils.degToRad(90), tuckedScale: 0.6 },
  { meshes: ['RearLandingGearR', 'RearWheelR'], axis: 'z', angle: -THREE.MathUtils.degToRad(90), tuckedScale: 0.6 },
];

/** Download the supplied A350 model, preferring the compressed copy. */
async function fetchA350ModelData(): Promise<ArrayBuffer> {
  if (typeof DecompressionStream !== 'undefined') {
    try {
      const res = await fetch('/models/SIA_A350.pack.gz');
      if (res.ok && res.body) {
        const packed = await new Response(
          res.body.pipeThrough(new DecompressionStream('gzip')),
        ).arrayBuffer();
        return unpackGlb(packed);
      }
    } catch {
      // Fall through to the uncompressed file.
    }
  }
  const res = await fetch('/models/SIA_A350.glb');
  if (!res.ok) throw new Error(`A350 model download failed: ${res.status}`);
  return res.arrayBuffer();
}

/**
 * The supplied A350's fuselage texture is a screenshot: the livery is right, but the "paint" behind it
 * is a lavender sky gradient, which made the whole aircraft look purple. Repaint those pixels white/light
 * grey and leave the navy/gold cheatline, lettering and windows untouched.
 */
export function cleanLiveryTexture(tex: THREE.Texture): void {
  const img = tex.image as CanvasImageSource & { width: number; height: number } | undefined;
  if (!img || !img.width) return;
  const canvas = document.createElement('canvas');
  canvas.width = img.width;
  canvas.height = img.height;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) return;
  ctx.drawImage(img, 0, 0);
  const data = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const px = data.data;
  for (let i = 0; i < px.length; i += 4) {
    const r = px[i], g = px[i + 1], b = px[i + 2];
    const lum = (r + g + b) / 3;
    if (b - r > 12 && lum > 95) {
      // Blue-tinted background -> near-white, keeping a little of the original shading for depth.
      const v = Math.min(252, 208 + lum * 0.25);
      px[i] = v; px[i + 1] = v; px[i + 2] = Math.min(255, v + 1);
    }
  }
  ctx.putImageData(data, 0, 0);
  tex.image = canvas;
  tex.needsUpdate = true;
}

const a350ModelDataPromise = fetchA350ModelData();
a350ModelDataPromise.catch(() => undefined);

// Scale that makes the A350 about 36 simulator units long.
const A350_MODEL_SCALE = 36 / 66.60654449;
export const MODEL_GROUND_DROP = 3.39;
export const AIRCRAFT_CENTRE_Y = 8.74912071 * A350_MODEL_SCALE - MODEL_GROUND_DROP;

// The supplied A350 GLB's known gear meshes.
const GEAR_MESH_NAMES = new Set([
  'SketchUpModel_7', 'SketchUpModel_8', 'SketchUpModel_10', 'SketchUpModel_13',
  'SketchUpModel_27', 'SketchUpModel_29', 'SketchUpModel_30', 'SketchUpModel_31',
  'SketchUpModel_32', 'SketchUpModel_33',
]);

const inMainZone = (c: THREE.Vector3) =>
  Math.abs(c.x) > 0.9 && Math.abs(c.x) < 3.6 && c.z > -2 && c.z < 1.2 && c.y < -0.3;
const mainLeg = (c: THREE.Vector3) => (c.x < 0 ? 1 : 2);

const PARTIAL_GEAR_MESHES: Record<string, (c: THREE.Vector3) => number> = {
  SketchUpModel_default: (c) =>
    Math.abs(c.x) < 1.6 && c.z < -13.9 && c.y < -0.3 ? 0 : inMainZone(c) ? mainLeg(c) : -1,
  SketchUpModel_43: (c) => (inMainZone(c) ? mainLeg(c) : -1),
};

const GEAR_TRAVEL_TIME = 5;

interface GearLeg {
  pivot: THREE.Group;
  axis: 'x' | 'z';
  angle: number;
  tuckedScale: number;
}

const NOSE_PIVOT = new THREE.Vector3(0, -0.6, -15.2);
const MAIN_PIVOT_LEFT = new THREE.Vector3(-1.3, -0.8, -0.35);
const MAIN_PIVOT_RIGHT = new THREE.Vector3(1.3, -0.8, -0.35);
const smoothstep = (t: number) => t * t * (3 - 2 * t);

// The supplied A380 FBX's gear meshes, grouped by leg. The FBX is static, so
// these are re-parented onto animated pivots just like the A350's gear.
const A380_GEAR_LEGS: Array<{ meshes: string[]; axis: 'x' | 'z'; angle: number; tuckedScale: number }> = [
  // Nose gear folds forward.
  {
    meshes: ['Group_104', 'Group_105', 'Group_106', 'Group_108', 'Group_109', 'Group_111'],
    axis: 'x', angle: Math.PI / 2, tuckedScale: 0.5,
  },
  // Wing gear folds inboard into the wing roots.
  {
    meshes: [
      'Group_169', 'Group_171', 'Group_172', 'Group_174', 'Group_175', 'Group_177',
      'Group_178', 'Group_180', 'Group_181', 'Group_183', 'Component#18_002',
    ],
    axis: 'z', angle: THREE.MathUtils.degToRad(100), tuckedScale: 0.7,
  },
  {
    meshes: [
      'Group_154', 'Group_156', 'Group_157', 'Group_159', 'Group_160', 'Group_162',
      'Group_163', 'Group_165', 'Group_166', 'Group_168', 'Component#18_001',
    ],
    axis: 'z', angle: -THREE.MathUtils.degToRad(100), tuckedScale: 0.7,
  },
  // Body gear folds aft into the fuselage.
  {
    meshes: [
      'Group_133', 'Group_135', 'Group_136', 'Group_138', 'Group_139', 'Group_141', 'Group_142',
      'Group_144', 'Group_145', 'Group_147', 'Group_148', 'Group_150', 'Group_151', 'Group_153',
    ],
    axis: 'x', angle: -Math.PI / 2, tuckedScale: 0.7,
  },
  {
    meshes: [
      'Group_112', 'Group_114', 'Group_115', 'Group_117', 'Group_118', 'Group_120', 'Group_121',
      'Group_123', 'Group_124', 'Group_126', 'Group_127', 'Group_129', 'Group_130', 'Group_132',
    ],
    axis: 'x', angle: -Math.PI / 2, tuckedScale: 0.7,
  },
];

// Air Force One's converted GLB (see public/models/AirForceOne.glb) ships its landing gear as separate
// named meshes, with tyres on the main legs. "Left"/"Right" are the aircraft's own sides (-X / +X).
const AF1_GEAR_LEGS: typeof A380_GEAR_LEGS = [
  // Nose gear folds forward.
  { meshes: ['AF1_GearNose'], axis: 'x', angle: Math.PI / 2, tuckedScale: 0.5 },
  // Wing gear folds inboard into the wing roots.
  { meshes: ['AF1_GearWingL'], axis: 'z', angle: THREE.MathUtils.degToRad(100), tuckedScale: 0.7 },
  { meshes: ['AF1_GearWingR'], axis: 'z', angle: -THREE.MathUtils.degToRad(100), tuckedScale: 0.7 },
  // Body gear folds aft into the fuselage.
  { meshes: ['AF1_GearBodyL'], axis: 'x', angle: -Math.PI / 2, tuckedScale: 0.7 },
  { meshes: ['AF1_GearBodyR'], axis: 'x', angle: -Math.PI / 2, tuckedScale: 0.7 },
];

/** Renders the A350, A380, F-16 or Air Force One as the aircraft. */
export class AircraftModel {
  group: THREE.Group;
  private aircraftType: AircraftType;
  private engineFans: THREE.Mesh[] = [];
  private engineGlows: THREE.Mesh[] = [];
  private gearLegs: GearLeg[] = [];
  private extension = 1;
  private placeholder: THREE.Group;
  private centreY = AIRCRAFT_CENTRE_Y;

  constructor(aircraftType: AircraftType = 'a350') {
    this.aircraftType = aircraftType;
    this.group = new THREE.Group();
    this.placeholder = this.buildPlaceholder();
    this.group.add(this.placeholder);
  }

  get gearExtension(): number {
    return this.extension;
  }

  /** Chase-camera distance multiplier (1 = airliner-sized). */
  get cameraScale(): number {
    return this.aircraftType === 'f16' ? 0.45 : 1;
  }

  /** Pilot eye position in aircraft space, or null to use the airliner flight-deck default. */
  get cockpitEye(): THREE.Vector3 | null {
    return this.aircraftType === 'f16' ? new THREE.Vector3(0, 2.7 - MODEL_GROUND_DROP, -2.2) : null;
  }

  get cameraCentreY(): number {
    return this.centreY;
  }

  private buildPlaceholder(): THREE.Group {
    const g = new THREE.Group();
    const mat = new THREE.MeshStandardMaterial({ color: 0xf2f4f5, roughness: 0.5 });
    const add = (geo: THREE.BufferGeometry, x: number, y: number, z: number, rx = 0) => {
      const m = new THREE.Mesh(geo, mat);
      m.position.set(x, y, z);
      m.rotation.x = rx;
      m.castShadow = true;
      m.frustumCulled = false;
      g.add(m);
    };
    add(new THREE.CylinderGeometry(1.6, 1.6, 30, 16), 0, 0, 0, Math.PI / 2);
    add(new THREE.ConeGeometry(1.6, 5, 16), 0, 0, -17.5, -Math.PI / 2);
    add(new THREE.ConeGeometry(1.6, 5, 16), 0, 0, 17.5, Math.PI / 2);
    add(new THREE.BoxGeometry(36, 0.25, 5), 0, -0.6, 1);
    add(new THREE.BoxGeometry(12, 0.2, 3), 0, 0.4, 16.5);
    add(new THREE.BoxGeometry(0.25, 5, 3.5), 0, 3, 16.2);
    for (const x of [-6, 6]) add(new THREE.CylinderGeometry(0.9, 0.9, 4, 12), x, -1.4, -2, Math.PI / 2);
    return g;
  }

  async loadModel(): Promise<void> {
    try {
      if (this.aircraftType === 'a350') {
        await this.loadA350();
      } else if (this.aircraftType === 'f16') {
        await this.loadF16();
      } else if (this.aircraftType === 'af1') {
        await this.loadAirForceOne();
      } else {
        await this.loadA380();
      }
    } catch (err) {
      console.error(`Failed to load ${this.aircraftType.toUpperCase()} model:`, err);
    }
  }

  private prepareLoadedObject(model: THREE.Object3D): void {
    model.traverse((obj) => {
      obj.visible = true;
      if (obj instanceof THREE.Mesh) {
        obj.castShadow = true;
        obj.receiveShadow = true;
        obj.frustumCulled = false;
        const mats: THREE.Material[] = Array.isArray(obj.material) ? obj.material : [obj.material];
        for (const mat of mats) {
          const map = (mat as THREE.MeshStandardMaterial).map;
          if (map && map.name === 'mat_0' && this.aircraftType === 'a350') cleanLiveryTexture(map);
          // The wing-root belly fairing is pure black in the source model; paint it light grey like the real thing.
          const std = mat as THREE.MeshStandardMaterial;
          if (this.aircraftType === 'a350' && obj.name === 'SketchUpModel_1' && std.color && std.color.getHex() === 0x000000) {
            std.color.setHex(0xaeb2b8);
          }
          if (mat.transparent && mat.opacity > 0.1) {
            mat.transparent = false;
            mat.opacity = 1;
            mat.depthWrite = true;
            mat.needsUpdate = true;
          }
        }
      }
    });
  }

  private async loadA350(): Promise<void> {
    const loader = new GLTFLoader();
    const gltf = await loader.parseAsync(await a350ModelDataPromise, '/models/');
    const model = gltf.scene;
    model.scale.setScalar(A350_MODEL_SCALE);
    model.position.set(
      31.65121841 * A350_MODEL_SCALE,
      -MODEL_GROUND_DROP,
      -33.30327225 * A350_MODEL_SCALE,
    );
    model.rotation.y = Math.PI;
    this.prepareLoadedObject(model);

    this.group.add(model);
    this.group.remove(this.placeholder);
    this.centreY = AIRCRAFT_CENTRE_Y;
    this.buildA350Gear(model);
    this.applyGear();
  }

  private async loadF16(): Promise<void> {
    const loader = new GLTFLoader();
    const gltf = await loader.loadAsync('/models/F-16D.gltf');
    const model = gltf.scene;
    // Drop the export's camera/lights; keep only the jet.
    const strip: THREE.Object3D[] = [];
    model.traverse((o) => { if (o.name === 'Camera' || o.name === 'HDRI Light' || (o as THREE.Light).isLight || (o as THREE.Camera).isCamera) strip.push(o); });
    strip.forEach((o) => o.removeFromParent());

    // Model nose points +Z; the simulator flies toward -Z.
    model.rotation.y = Math.PI;
    model.updateMatrixWorld(true);
    const box = new THREE.Box3().setFromObject(model);
    const size = box.getSize(new THREE.Vector3());
    model.scale.setScalar(F16_LENGTH / Math.max(size.x, size.z, 0.001));
    model.updateMatrixWorld(true);
    const scaled = new THREE.Box3().setFromObject(model);
    const centre = scaled.getCenter(new THREE.Vector3());
    model.position.x -= centre.x;
    model.position.y = -MODEL_GROUND_DROP - scaled.min.y;
    model.position.z -= centre.z;
    model.updateMatrixWorld(true);
    this.prepareLoadedObject(model);

    this.group.add(model);
    this.group.remove(this.placeholder);
    this.centreY = new THREE.Box3().setFromObject(model).getCenter(new THREE.Vector3()).y;
    this.buildA380Gear(model, F16_GEAR_LEGS);
    this.applyGear();
  }

  private async loadAirForceOne(): Promise<void> {
    const gltf = await new GLTFLoader().loadAsync('/models/AirForceOne.glb');
    const model = gltf.scene;
    // The GLB is pre-baked for the simulator: nose toward -Z, centred on X/Z, ~35 units long, livery in
    // vertex colours, with the tyre contact plane at y = 0. Only the local ground reference needs applying.
    model.position.y = -MODEL_GROUND_DROP;
    model.updateMatrixWorld(true);
    this.prepareLoadedObject(model);

    this.group.add(model);
    this.group.remove(this.placeholder);
    this.centreY = new THREE.Box3().setFromObject(model).getCenter(new THREE.Vector3()).y;
    this.buildA380Gear(model, AF1_GEAR_LEGS);
    this.applyGear();
  }

  private async loadA380(): Promise<void> {
    const res = await fetch('/models/A380.fbx');
    if (!res.ok) throw new Error(`A380 model download failed: ${res.status}`);
    const data = await res.arrayBuffer();

    const loader = new FBXLoader();
    const model = loader.parse(data, '/models/');

    // The supplied FBX is Y-up with +Z as its front axis. The simulator uses -Z
    // as aircraft-forward, so we only need a single 180-degree yaw correction.
    // Do not infer orientation from the raw vertex bounds because FBX geometry may
    // contain transformed child nodes whose local bounds are not the aircraft axes.
    model.rotation.y = Math.PI;
    model.updateMatrixWorld(true);

    // Normalize the imported FBX into the same simulator coordinate system as the A350:
    // 36 units long, centered on X/Z. The A350/controller pair uses a world runway
    // reference of 3.5, with the runway itself at ~0.1, so the A380's local wheel
    // ground plane must be -3.39 rather than 0.
    const orientedBox = new THREE.Box3().setFromObject(model);
    const orientedSize = orientedBox.getSize(new THREE.Vector3());
    const rawLength = Math.max(orientedSize.x, orientedSize.z);
    const scale = 36 / Math.max(rawLength, 0.001);
    model.scale.setScalar(scale);
    model.updateMatrixWorld(true);

    const scaledBox = new THREE.Box3().setFromObject(model);
    const centre = scaledBox.getCenter(new THREE.Vector3());
    // The FBX includes its own landing gear, so its lowest point is the tyre
    // contact patch: pin it to the -3.39 local runway reference.
    model.position.x -= centre.x;
    model.position.y = -MODEL_GROUND_DROP - scaledBox.min.y;
    model.position.z -= centre.z;
    model.updateMatrixWorld(true);
    this.prepareLoadedObject(model);

    this.group.add(model);
    this.group.remove(this.placeholder);

    // The A380's model is vertically offset relative to the controller origin, so
    // use the actual model centre rather than assuming the centre is size/2.
    this.centreY = new THREE.Box3().setFromObject(model).getCenter(new THREE.Vector3()).y;

    this.buildA380Gear(model);
    this.applyGear();
  }

  private buildA350Gear(model: THREE.Object3D): void {
    model.updateMatrixWorld(true);
    const gearMeshes: THREE.Mesh[] = [];
    model.traverse((obj) => {
      if (obj instanceof THREE.Mesh && (GEAR_MESH_NAMES.has(obj.name) || obj.name in PARTIAL_GEAR_MESHES)) {
        gearMeshes.push(obj);
      }
    });
    if (gearMeshes.length === 0) {
      console.warn('No landing gear meshes found in the A350 model.');
      return;
    }

    const legDefs: Array<{ pivotAt: THREE.Vector3; axis: 'x' | 'z'; angle: number; tuckedScale: number }> = [
      { pivotAt: NOSE_PIVOT, axis: 'x', angle: Math.PI / 2, tuckedScale: 0.5 },
      { pivotAt: MAIN_PIVOT_LEFT, axis: 'z', angle: THREE.MathUtils.degToRad(120), tuckedScale: 0.75 },
      { pivotAt: MAIN_PIVOT_RIGHT, axis: 'z', angle: -THREE.MathUtils.degToRad(120), tuckedScale: 0.75 },
    ];
    this.gearLegs = legDefs.map((d) => {
      const pivot = new THREE.Group();
      pivot.position.copy(d.pivotAt);
      this.group.add(pivot);
      return { pivot, axis: d.axis, angle: d.angle, tuckedScale: d.tuckedScale };
    });

    const v = new THREE.Vector3();
    const centroid = new THREE.Vector3();

    for (const mesh of gearMeshes) {
      mesh.updateMatrix();
      const toAircraft = new THREE.Matrix4().multiplyMatrices(model.matrix, mesh.matrix);
      const geo = mesh.geometry as THREE.BufferGeometry;
      const pos = geo.getAttribute('position');
      const index = geo.index;
      const triCount = (index ? index.count : pos.count) / 3;
      const partial = PARTIAL_GEAR_MESHES[mesh.name] as ((c: THREE.Vector3) => number) | undefined;
      const buckets: number[][] = [[], [], []];
      const rest: number[] = [];

      for (let t = 0; t < triCount; t++) {
        const ids = [0, 1, 2].map((k) => (index ? index.getX(t * 3 + k) : t * 3 + k));
        centroid.set(0, 0, 0);
        for (const i of ids) centroid.add(v.fromBufferAttribute(pos, i));
        centroid.multiplyScalar(1 / 3).applyMatrix4(toAircraft);
        const b = partial ? partial(centroid) : centroid.z < -8 ? 0 : centroid.x < 0 ? 1 : 2;
        (b < 0 ? rest : buckets[b]).push(ids[0], ids[1], ids[2]);
      }

      buckets.forEach((indices, b) => {
        if (indices.length === 0) return;
        const part = new THREE.BufferGeometry();
        for (const name of Object.keys(geo.attributes)) part.setAttribute(name, geo.attributes[name]);
        part.setIndex(indices);
        const piece = new THREE.Mesh(part, mesh.material);
        piece.castShadow = true;
        piece.receiveShadow = true;
        piece.frustumCulled = false;
        new THREE.Matrix4()
          .makeTranslation(-legDefs[b].pivotAt.x, -legDefs[b].pivotAt.y, -legDefs[b].pivotAt.z)
          .multiply(toAircraft)
          .decompose(piece.position, piece.quaternion, piece.scale);
        this.gearLegs[b].pivot.add(piece);
      });

      if (partial && rest.length > 0) geo.setIndex(rest);
      else mesh.removeFromParent();
    }
  }

  private buildA380Gear(model: THREE.Object3D, legDefs: typeof A380_GEAR_LEGS = A380_GEAR_LEGS): void {
    this.group.updateMatrixWorld(true);
    const toGroup = new THREE.Matrix4().copy(this.group.matrixWorld).invert();

    for (const def of legDefs) {
      const meshes = def.meshes
        .map((name) => model.getObjectByName(name))
        .filter((obj): obj is THREE.Mesh => obj instanceof THREE.Mesh);
      if (meshes.length === 0) {
        console.warn('No landing gear meshes found for an A380 gear leg.');
        continue;
      }

      // Hinge each leg at the top centre of its strut, inside the wing/fuselage.
      const bounds = new THREE.Box3();
      for (const mesh of meshes) bounds.union(new THREE.Box3().setFromObject(mesh));
      bounds.applyMatrix4(toGroup);
      const pivot = new THREE.Group();
      pivot.position.set(
        (bounds.min.x + bounds.max.x) / 2,
        bounds.max.y,
        (bounds.min.z + bounds.max.z) / 2,
      );
      this.group.add(pivot);
      pivot.updateMatrixWorld(true);
      for (const mesh of meshes) pivot.attach(mesh);

      this.gearLegs.push({ pivot, axis: def.axis, angle: def.angle, tuckedScale: def.tuckedScale });
    }
  }

  private applyGear(): void {
    const retract = 1 - smoothstep(this.extension);
    for (const leg of this.gearLegs) {
      leg.pivot.rotation.set(0, 0, 0);
      leg.pivot.rotation[leg.axis] = leg.angle * retract;
      leg.pivot.scale.setScalar(1 - (1 - leg.tuckedScale) * retract);
      leg.pivot.visible = this.extension > 0.02;
    }
  }

  updateAnimation(
    _roll: number,
    _pitch: number,
    _yaw: number,
    throttle: number,
    dt: number,
    targetGear: number,
    _targetFlap: number,
  ): void {
    const target = targetGear > 0.5 ? 1 : 0;
    const step = dt / GEAR_TRAVEL_TIME;
    this.extension = target > this.extension
      ? Math.min(target, this.extension + step)
      : Math.max(target, this.extension - step);
    this.applyGear();

    this.engineFans.forEach((fan) => {
      fan.rotation.z += dt * (throttle * 25 + 5);
    });
    this.engineGlows.forEach((glow) => {
      (glow.material as THREE.MeshBasicMaterial).opacity = 0.05 + throttle * 0.25;
    });
  }
}
