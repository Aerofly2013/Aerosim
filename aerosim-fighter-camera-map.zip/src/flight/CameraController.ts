import * as THREE from 'three';
import { AircraftController } from './AircraftController';
import { MODEL_GROUND_DROP } from './AircraftModel';

export class CameraController {
  private camera: THREE.PerspectiveCamera;
  private getAircraftCentreY: () => number;
  private getScale: () => number = () => 1;
  private getCockpitEye: () => THREE.Vector3 | null = () => null;
  private mode: 'thirdPerson' | 'cockpit' | 'gear' = 'thirdPerson';
  private modes: Array<'thirdPerson' | 'cockpit' | 'gear'> = ['thirdPerson', 'cockpit', 'gear'];
  private currentOffset = new THREE.Vector3();
  private initialized = false;
  // Multiplier on the chase-camera distance (1 = default). Set per aircraft.
  private chaseZoom = 1;

  // Mouse look: orbits the chase camera / turns the cockpit view. Radians,
  // relative to straight-ahead, reset whenever the camera mode changes.
  private lookYaw = 0;
  private lookPitch = 0;
  private readonly LOOK_YAW_LIMIT = THREE.MathUtils.degToRad(120);
  private readonly LOOK_PITCH_LIMIT = THREE.MathUtils.degToRad(70);

  constructor(
    camera: THREE.PerspectiveCamera,
    getAircraftCentreY: () => number,
    getScale?: () => number,
    getCockpitEye?: () => THREE.Vector3 | null,
  ) {
    if (getScale) this.getScale = getScale;
    if (getCockpitEye) this.getCockpitEye = getCockpitEye;
    this.camera = camera;
    this.getAircraftCentreY = getAircraftCentreY;
  }

  /** Pulls the external chase camera back (>1) or in (<1), keeping the same viewing angle. */
  setChaseZoom(zoom: number): void {
    this.chaseZoom = zoom;
    this.initialized = false;
  }

  toggleMode(): void {
    const idx = this.modes.indexOf(this.mode);
    this.mode = this.modes[(idx + 1) % this.modes.length];
    this.initialized = false;
    this.lookYaw = 0;
    this.lookPitch = 0;
  }

  /**
   * Called after a restart. The aircraft teleports, so the camera must jump
   * to the new spot too — but it keeps its current facing and smoothly swings
   * back to dead-behind over the next update() calls, instead of snapping
   * straight there, which read as the camera suddenly zooming in.
   */
  snap(): void {
    this.lookYaw = 0;
    this.lookPitch = 0;
  }

  /** Applies a mouse-drag delta (in pixels) to the look direction. */
  lookAround(dxPixels: number, dyPixels: number): void {
    const sensitivity = 0.0025;
    this.lookYaw = THREE.MathUtils.clamp(
      this.lookYaw - dxPixels * sensitivity, -this.LOOK_YAW_LIMIT, this.LOOK_YAW_LIMIT);
    this.lookPitch = THREE.MathUtils.clamp(
      this.lookPitch - dyPixels * sensitivity, -this.LOOK_PITCH_LIMIT, this.LOOK_PITCH_LIMIT);
  }

  /** The mouse-look rotation, applied in the aircraft's local frame before its own attitude. */
  private get lookQuaternion(): THREE.Quaternion {
    return new THREE.Quaternion().setFromEuler(new THREE.Euler(this.lookPitch, this.lookYaw, 0, 'YXZ'));
  }

  /**
   * `camera.lookAt()` builds its orientation from the camera-to-target
   * direction crossed with `camera.up`. When the aircraft points nearly
   * straight up (or down) that direction becomes nearly parallel to the
   * default world-up (0,1,0), and the cross product collapses toward zero —
   * the camera then spins/flips wildly frame to frame ("buggy when you face
   * up"). As the view direction approaches that singularity, blend the up
   * vector toward the aircraft's own up so it's never parallel to the view.
   */
  private computeStableUp(rotation: THREE.Euler, viewDir: THREE.Vector3): THREE.Vector3 {
    const worldUp = new THREE.Vector3(0, 1, 0);
    const alignment = Math.abs(viewDir.dot(worldUp));
    if (alignment < 0.9) return worldUp;
    const aircraftUp = new THREE.Vector3(0, 1, 0).applyEuler(rotation);
    const t = THREE.MathUtils.clamp((alignment - 0.9) / 0.09, 0, 1);
    return worldUp.lerp(aircraftUp, t).normalize();
  }

  getMode(): string {
    return this.mode;
  }

  update(aircraft: AircraftController, dt: number): void {
    if (this.mode === 'thirdPerson') {
      this.updateThirdPerson(aircraft, dt);
    } else if (this.mode === 'cockpit') {
      this.updateCockpit(aircraft);
    } else {
      this.updateGearView(aircraft, dt);
    }
  }

  /**
   * Chase camera. The camera always looks at the aircraft's centre and only the
   * *direction* of its offset is smoothed, so the plane stays locked to the
   * centre of the screen at any speed while the camera still swings smoothly
   * through turns.
   */
  private updateChase(aircraft: AircraftController, dt: number, localOffset: THREE.Vector3): void {
    const rotation = aircraft.state.rotation;
    const centre = aircraft.state.position.clone()
      .add(new THREE.Vector3(0, this.getAircraftCentreY(), 0).applyEuler(rotation));
    const targetOffset = localOffset.clone().applyQuaternion(this.lookQuaternion).applyEuler(rotation);

    if (!this.initialized) {
      this.currentOffset.copy(targetOffset);
      this.initialized = true;
    } else {
      this.currentOffset.lerp(targetOffset, Math.min(1, dt * 2.5));
      this.currentOffset.setLength(targetOffset.length());
    }

    this.camera.position.copy(centre).add(this.currentOffset);
    const viewDir = centre.clone().sub(this.camera.position);
    if (viewDir.lengthSq() > 1e-6) {
      this.camera.up.copy(this.computeStableUp(rotation, viewDir.normalize()));
    }
    this.camera.lookAt(centre);
  }

  private updateThirdPerson(aircraft: AircraftController, dt: number): void {
    // Same camera spot as before (0, 6, 28 from the origin), expressed from the plane's centre.
    this.updateChase(aircraft, dt, new THREE.Vector3(0, (6 - this.getAircraftCentreY()) * this.getScale(), 28 * this.getScale()).multiplyScalar(this.chaseZoom));
  }

  private updateCockpit(aircraft: AircraftController): void {
    // Flight deck: just behind the nose, at fuselage window height.
    const cockpitOffset = this.getCockpitEye() ?? new THREE.Vector3(0, 3.9 - MODEL_GROUND_DROP, -14.5);
    cockpitOffset.applyEuler(aircraft.state.rotation);
    const pos = aircraft.state.position.clone().add(cockpitOffset);
    this.camera.position.copy(pos);

    const lookDir = new THREE.Vector3(0, 0, -1)
      .applyQuaternion(this.lookQuaternion)
      .applyEuler(aircraft.state.rotation);
    this.camera.up.copy(this.computeStableUp(aircraft.state.rotation, lookDir));
    this.camera.lookAt(pos.clone().addScaledVector(lookDir, 50));
  }

  private updateGearView(aircraft: AircraftController, dt: number): void {
    // Low angle looking at the aircraft from behind/below — great for landing
    this.updateChase(aircraft, dt, new THREE.Vector3(0, (1.5 - this.getAircraftCentreY()) * this.getScale(), 18 * this.getScale()));
  }
}
