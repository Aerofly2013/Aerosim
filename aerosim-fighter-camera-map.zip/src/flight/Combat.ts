import * as THREE from 'three';
import { AircraftModel } from './AircraftModel';
import { CrashEffects } from './CrashEffects';
import { terrainHeight, SEA_LEVEL } from './world';

const MAX_BULLETS = 80;
const BULLET_SPEED = 1100;     // m/s, on top of the shooter's own velocity
const BULLET_LIFE = 1.5;       // seconds
const FIRE_INTERVAL = 0.07;    // ~14 rounds/s
const TARGET_RADIUS = 16;      // generous hit sphere around an airliner
const DRONE_HP = 10;           // bullets needed to bring down a drone
const MAX_SMOKE = 120;

let puffTex: THREE.Texture | null = null;
function getPuffTex(): THREE.Texture {
  if (puffTex) return puffTex;
  const c = document.createElement('canvas');
  c.width = c.height = 64;
  const g = c.getContext('2d')!;
  const grad = g.createRadialGradient(32, 32, 2, 32, 32, 32);
  grad.addColorStop(0, 'rgba(255,255,255,1)');
  grad.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = grad;
  g.fillRect(0, 0, 64, 64);
  puffTex = new THREE.CanvasTexture(c);
  return puffTex;
}

interface Bullet { mesh: THREE.Mesh; vel: THREE.Vector3; life: number; }
interface Puff { sprite: THREE.Sprite; life: number; max: number; vel: THREE.Vector3; }

/** Anything a bullet can hit. */
export interface Target {
  id: string;
  position: THREE.Vector3;
  radius: number;
  alive: boolean;
}

/** An AI plane that flies in circles until shot, then spirals down and explodes. */
class Drone implements Target {
  id: string;
  model: AircraftModel;
  position = new THREE.Vector3();
  radius = TARGET_RADIUS;
  alive = true;
  hp = DRONE_HP;
  private centre: THREE.Vector3;
  private orbit: number;
  private angle: number;
  private dir: number;
  private speed = 110;
  private heading = 0;
  private fallVy = 0;
  private fallRoll = 0;
  private spin = 1;
  respawnIn = -1;

  constructor(id: string, centre: THREE.Vector3, orbit: number, angle: number, dir: number) {
    this.id = id;
    this.centre = centre;
    this.orbit = orbit;
    this.angle = angle;
    this.dir = dir;
    this.model = new AircraftModel('a350');
    void this.model.loadModel();
    this.place(0);
  }

  private place(dt: number): void {
    this.angle += (this.speed / this.orbit) * this.dir * dt;
    this.position.set(
      this.centre.x + Math.cos(this.angle) * this.orbit,
      this.centre.y,
      this.centre.z + Math.sin(this.angle) * this.orbit,
    );
    // Tangent direction of the circle; the model's nose points along -Z.
    const tx = -Math.sin(this.angle) * this.dir;
    const tz = Math.cos(this.angle) * this.dir;
    this.heading = Math.atan2(-tx, -tz);
    this.model.group.position.copy(this.position);
    this.model.group.rotation.set(0, this.heading, -0.25 * this.dir, 'YXZ');
  }

  fly(dt: number): void {
    this.place(dt);
    try { this.model.updateAnimation(0, 0, 0, 0.7, dt, 0, 0); } catch { /* model still loading */ }
  }

  /** Falling out of the sky. Returns true the frame it hits the ground. */
  fall(dt: number): boolean {
    this.fallVy -= 28 * dt;
    this.fallRoll += this.spin * 2.4 * dt;
    const fx = -Math.sin(this.heading), fz = -Math.cos(this.heading);
    this.position.x += fx * this.speed * dt;
    this.position.z += fz * this.speed * dt;
    this.position.y += this.fallVy * dt;
    this.model.group.position.copy(this.position);
    this.model.group.rotation.set(Math.min(0.9, (-this.fallVy) / 120), this.heading, this.fallRoll, 'YXZ');
    const ground = Math.max(terrainHeight(this.position.x, this.position.z), SEA_LEVEL);
    return this.position.y <= ground + 3;
  }

  kill(): void {
    this.alive = false;
    this.fallVy = 0;
    this.spin = Math.random() < 0.5 ? -1 : 1;
  }

  revive(): void {
    this.alive = true;
    this.hp = DRONE_HP;
    this.respawnIn = -1;
    this.model.group.visible = true;
    this.place(0);
  }
}

/** Guns, tracer bullets, hit detection, AI target planes and wreck effects. */
export class Combat {
  private scene: THREE.Scene;
  private bullets: Bullet[] = [];
  private puffs: Puff[] = [];
  private cooldown = 0;
  private drones: Drone[] = [];
  private effects = new CrashEffects();
  private flash: THREE.Mesh[] = [];
  private flashGeo = new THREE.SphereGeometry(1.4, 8, 6);
  private flashMat = new THREE.MeshBasicMaterial({ color: 0xffd27a, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false });
  private bulletGeo = new THREE.BoxGeometry(0.35, 0.35, 14);
  private bulletMat = new THREE.MeshBasicMaterial({ color: 0xffe28a, blending: THREE.AdditiveBlending, depthWrite: false });
  private flashes: Array<{ mesh: THREE.Mesh; life: number }> = [];
  private _a = new THREE.Vector3();
  private _b = new THREE.Vector3();
  private _c = new THREE.Vector3();

  /** Fired when a bullet strikes any target (id of the target). */
  onHit?: (id: string) => void;
  /** Fired when a drone is destroyed. */
  onDroneDown?: () => void;

  constructor(scene: THREE.Scene) {
    this.scene = scene;
    this.effects.attach(scene);
    for (let i = 0; i < MAX_BULLETS; i++) {
      const mesh = new THREE.Mesh(this.bulletGeo, this.bulletMat);
      mesh.visible = false;
      mesh.frustumCulled = false;
      scene.add(mesh);
      this.bullets.push({ mesh, vel: new THREE.Vector3(), life: 0 });
    }
    for (let i = 0; i < MAX_SMOKE; i++) {
      const mat = new THREE.SpriteMaterial({ map: getPuffTex(), transparent: true, depthWrite: false, color: 0x333333 });
      const sprite = new THREE.Sprite(mat);
      sprite.visible = false;
      scene.add(sprite);
      this.puffs.push({ sprite, life: 0, max: 1, vel: new THREE.Vector3() });
    }
  }

  /** Spawns a few slow circling target planes around a point. */
  spawnDrones(centre: THREE.Vector3, count = 3): void {
    for (let i = 0; i < count; i++) {
      const c = new THREE.Vector3(centre.x, 450 + i * 120, centre.z);
      const d = new Drone(`drone${i}`, c, 1200 + i * 500, (i / count) * Math.PI * 2, i % 2 ? -1 : 1);
      this.scene.add(d.model.group);
      this.drones.push(d);
    }
  }

  get targets(): Target[] {
    return this.drones.filter((d) => d.alive);
  }

  /** Visible tracer position for the minimap/HUD if wanted. */
  dronePositions(): THREE.Vector3[] {
    return this.drones.filter((d) => d.alive).map((d) => d.position);
  }

  /** Wreck explosion for any aircraft (used for remote players too). */
  explode(position: THREE.Vector3, rotation: THREE.Euler, velocity: THREE.Vector3): void {
    this.effects.trigger(position, rotation, velocity);
  }

  tryFire(origin: THREE.Vector3, quat: THREE.Quaternion, shooterVel: THREE.Vector3, dt: number, trigger: boolean): void {
    this.cooldown -= dt;
    if (!trigger || this.cooldown > 0) return;
    this.cooldown = FIRE_INTERVAL;
    const dir = this._a.set(0, 0, -1).applyQuaternion(quat);
    // Alternate between the two wing-root guns.
    this._flip = !this._flip;
    const muzzle = this._b.set(this._flip ? 1.2 : -1.2, -0.3, -6).applyQuaternion(quat).add(origin);
    const b = this.bullets.find((x) => x.life <= 0);
    if (!b) return;
    b.life = BULLET_LIFE;
    b.vel.copy(dir).multiplyScalar(BULLET_SPEED).add(shooterVel);
    b.mesh.position.copy(muzzle);
    b.mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, -1), b.vel.clone().normalize());
    b.mesh.visible = true;
  }
  private _flip = false;

  update(dt: number, remoteTargets: Target[]): void {
    this.effects.update(dt);

    // Drones
    for (const d of this.drones) {
      if (d.alive) {
        d.fly(dt);
      } else if (d.respawnIn < 0) {
        // Falling: leave a smoke trail, explode on impact.
        this.puff(d.position, 0.9);
        if (d.fall(dt)) {
          d.model.group.visible = false;
          this._c.set(0, 0, 0);
          this.effects.trigger(d.position.clone(), d.model.group.rotation.clone(), new THREE.Vector3(0, -30, 0));
          d.respawnIn = 12;
        }
      } else {
        d.respawnIn -= dt;
        if (d.respawnIn <= 0) d.revive();
      }
    }

    // Bullets
    const all: Target[] = [...this.drones.filter((d) => d.alive), ...remoteTargets];
    for (const b of this.bullets) {
      if (b.life <= 0) continue;
      b.life -= dt;
      const from = this._a.copy(b.mesh.position);
      const step = this._b.copy(b.vel).multiplyScalar(dt);
      const to = this._c.copy(from).add(step);
      let hitTarget: Target | null = null;
      for (const t of all) {
        if (segmentHitsSphere(from, to, t.position, t.radius)) { hitTarget = t; break; }
      }
      if (hitTarget) {
        this.spark(to);
        b.life = 0;
        b.mesh.visible = false;
        this.registerHit(hitTarget);
        continue;
      }
      b.mesh.position.copy(to);
      if (b.life <= 0 || to.y < Math.max(terrainHeight(to.x, to.z), SEA_LEVEL)) {
        b.life = 0;
        b.mesh.visible = false;
      }
    }

    // Smoke
    for (const p of this.puffs) {
      if (p.life <= 0) continue;
      p.life -= dt;
      if (p.life <= 0) { p.sprite.visible = false; continue; }
      const k = 1 - p.life / p.max;
      p.sprite.position.addScaledVector(p.vel, dt);
      p.sprite.scale.setScalar(8 + k * 40);
      (p.sprite.material as THREE.SpriteMaterial).opacity = 0.7 * (1 - k);
    }

    // Hit sparks
    for (let i = this.flashes.length - 1; i >= 0; i--) {
      const f = this.flashes[i];
      f.life -= dt;
      f.mesh.scale.setScalar(1 + (0.15 - f.life) * 25);
      if (f.life <= 0) { this.scene.remove(f.mesh); this.flashes.splice(i, 1); }
    }
  }

  private registerHit(t: Target): void {
    const d = this.drones.find((x) => x.id === t.id);
    if (d) {
      d.hp -= 1;
      if (d.hp <= 0 && d.alive) {
        d.kill();
        this.onDroneDown?.();
      }
      return;
    }
    this.onHit?.(t.id);
  }

  private spark(pos: THREE.Vector3): void {
    const mesh = new THREE.Mesh(this.flashGeo, this.flashMat);
    mesh.position.copy(pos);
    this.scene.add(mesh);
    this.flashes.push({ mesh, life: 0.15 });
  }

  private puff(pos: THREE.Vector3, rate: number): void {
    if (Math.random() > rate) return;
    const p = this.puffs.find((x) => x.life <= 0);
    if (!p) return;
    p.life = p.max = 2.2;
    p.sprite.position.copy(pos);
    p.sprite.visible = true;
    p.vel.set((Math.random() - 0.5) * 4, 3 + Math.random() * 3, (Math.random() - 0.5) * 4);
  }

  /** Smoke from a damaged remote plane. */
  smokeAt(pos: THREE.Vector3): void { this.puff(pos, 0.6); }

  clearEffects(): void { this.effects.clear(); }

  dispose(): void {
    this.effects.dispose();
    for (const p of this.puffs) (p.sprite.material as THREE.SpriteMaterial).dispose();
    this.bulletGeo.dispose(); this.bulletMat.dispose();
    this.flashGeo.dispose(); this.flashMat.dispose();
  }
}

function segmentHitsSphere(a: THREE.Vector3, b: THREE.Vector3, c: THREE.Vector3, r: number): boolean {
  const abx = b.x - a.x, aby = b.y - a.y, abz = b.z - a.z;
  const len2 = abx * abx + aby * aby + abz * abz || 1e-6;
  let t = ((c.x - a.x) * abx + (c.y - a.y) * aby + (c.z - a.z) * abz) / len2;
  t = Math.max(0, Math.min(1, t));
  const dx = a.x + abx * t - c.x, dy = a.y + aby * t - c.y, dz = a.z + abz * t - c.z;
  return dx * dx + dy * dy + dz * dz <= r * r;
}
