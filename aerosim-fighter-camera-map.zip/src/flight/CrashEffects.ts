import * as THREE from 'three';
import { createHit, queryWorld } from './collision';

/**
 * Crash visuals: the aircraft breaks into a fixed set of chunks that tumble
 * and settle under gravity, plus an explosion flash and fire/smoke.
 *
 * Everything here is pre-allocated once (geometries, materials, textures, and
 * the particle pool) and only ever repositioned/reset on each crash — no
 * per-crash allocation of GPU resources — so replaying a crash any number of
 * times never grows memory or the number of draw calls.
 */

const GRAVITY = 9.81;
// Level ground: where a chunk's centre rests (a little above the surface).
const GROUND_Y = 0.2;
// How "fat" a chunk is when it collides with buildings, mountains and hills.
const DEBRIS_MARGIN = 0.45;
// Bounce off solid surfaces, matching how chunks already bounce off the ground.
const RESTITUTION = 0.12;
const SURFACE_FRICTION = 0.5;
const MAX_WRECK_TIME = 20;
const MAX_SMOKE = 20;
const MAX_FIRE = 10;

function makeRadialTexture(inner: string, outer: string): THREE.Texture {
  const size = 64;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const g = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  g.addColorStop(0, inner);
  g.addColorStop(1, outer);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);
  return new THREE.CanvasTexture(canvas);
}

// Created once and shared by every sprite of that kind, for the lifetime of the app.
const SMOKE_TEX = makeRadialTexture('rgba(70,66,62,0.85)', 'rgba(70,66,62,0)');
const FIRE_TEX = makeRadialTexture('rgba(255,230,170,1)', 'rgba(255,70,0,0)');
const FLASH_TEX = makeRadialTexture('rgba(255,255,255,1)', 'rgba(255,170,60,0)');

const HULL_MAT = new THREE.MeshStandardMaterial({ color: 0xe6e8e8, roughness: 0.55, metalness: 0.05 });
const BURNT_MAT = new THREE.MeshStandardMaterial({ color: 0x2a2624, roughness: 0.95 });
const ENGINE_MAT = new THREE.MeshStandardMaterial({ color: 0x1b1b1b, roughness: 0.6, metalness: 0.3 });

interface DebrisDef {
  geometry: THREE.BufferGeometry;
  material: THREE.Material;
  position: THREE.Vector3;
  rotX?: number;
}

// Rough chunks of the airframe (aircraft-local coordinates, same scale as the
// real model) so a crash reads as "the plane broke apart" without needing to
// carve up the actual GLB mesh.
const DEBRIS_DEFS: DebrisDef[] = [
  { geometry: new THREE.ConeGeometry(1.6, 6, 10), material: HULL_MAT, position: new THREE.Vector3(0, 0, -20), rotX: -Math.PI / 2 },
  { geometry: new THREE.CylinderGeometry(1.6, 1.6, 16, 10), material: HULL_MAT, position: new THREE.Vector3(0.4, -0.2, -9), rotX: Math.PI / 2 },
  { geometry: new THREE.CylinderGeometry(1.5, 1.6, 14, 10), material: BURNT_MAT, position: new THREE.Vector3(-0.6, 0.2, 8), rotX: Math.PI / 2 },
  { geometry: new THREE.ConeGeometry(1.5, 6, 10), material: HULL_MAT, position: new THREE.Vector3(0, 0.3, 17.5), rotX: Math.PI / 2 },
  { geometry: new THREE.BoxGeometry(17, 0.3, 5), material: HULL_MAT, position: new THREE.Vector3(-9, -0.6, 1) },
  { geometry: new THREE.BoxGeometry(17, 0.3, 5), material: BURNT_MAT, position: new THREE.Vector3(9, -0.6, 1) },
  { geometry: new THREE.BoxGeometry(12, 0.2, 3), material: HULL_MAT, position: new THREE.Vector3(0, 0.4, 16.5) },
  { geometry: new THREE.BoxGeometry(0.3, 5, 3.5), material: HULL_MAT, position: new THREE.Vector3(0, 3, 16.2) },
  { geometry: new THREE.CylinderGeometry(0.9, 0.9, 4, 8), material: ENGINE_MAT, position: new THREE.Vector3(-6, -1.4, -2), rotX: Math.PI / 2 },
  { geometry: new THREE.CylinderGeometry(0.9, 0.9, 4, 8), material: ENGINE_MAT, position: new THREE.Vector3(6, -1.4, -2), rotX: Math.PI / 2 },
];

interface Debris {
  mesh: THREE.Mesh;
  velocity: THREE.Vector3;
  angularVelocity: THREE.Vector3;
  settled: boolean;
}

interface Particle {
  sprite: THREE.Sprite;
  velocity: THREE.Vector3;
  age: number;
  life: number;
  baseOpacity: number;
  active: boolean;
}

function makeSprite(tex: THREE.Texture, blending: THREE.Blending): THREE.Sprite {
  const mat = new THREE.SpriteMaterial({
    map: tex, transparent: true, opacity: 0, depthWrite: false, blending,
  });
  const sprite = new THREE.Sprite(mat);
  sprite.visible = false;
  sprite.frustumCulled = false;
  return sprite;
}

function makeParticle(tex: THREE.Texture, blending: THREE.Blending): Particle {
  return { sprite: makeSprite(tex, blending), velocity: new THREE.Vector3(), age: 0, life: 1, baseOpacity: 0.6, active: false };
}

export class CrashEffects {
  private scene: THREE.Scene | null = null;
  private debris: Debris[] = [];
  private smokePool: Particle[] = [];
  private firePool: Particle[] = [];
  private flash: THREE.Sprite;
  private flashAge = 0;
  private active = false;
  private elapsed = 0;
  private hit = createHit();
  private crashPos = new THREE.Vector3();
  private nextFireAt = 0;
  private nextSmokeAt = 0;

  constructor() {
    this.flash = makeSprite(FLASH_TEX, THREE.AdditiveBlending);
    for (let i = 0; i < MAX_SMOKE; i++) this.smokePool.push(makeParticle(SMOKE_TEX, THREE.NormalBlending));
    for (let i = 0; i < MAX_FIRE; i++) this.firePool.push(makeParticle(FIRE_TEX, THREE.AdditiveBlending));
  }

  /** Adds the (currently invisible) pooled objects to the scene. Call once. */
  attach(scene: THREE.Scene): void {
    this.scene = scene;
    scene.add(this.flash);
    for (const p of this.smokePool) scene.add(p.sprite);
    for (const p of this.firePool) scene.add(p.sprite);
  }

  /**
   * Starts a crash sequence at the point of impact. Safe to call repeatedly.
   * `surfaceNormal` is given when the aircraft flew into something solid (a
   * building, mountain or hillside): the part of its momentum driving into the
   * surface is turned into a small rebound, so the wreckage drops down the
   * face of the obstacle instead of being thrown into it.
   */
  trigger(position: THREE.Vector3, rotation: THREE.Euler, velocity: THREE.Vector3, surfaceNormal?: THREE.Vector3): void {
    if (!this.scene) return;
    this.clearDebris();
    this.active = true;
    this.elapsed = 0;
    this.crashPos.copy(position);

    const carried = velocity.clone().multiplyScalar(0.5);
    if (surfaceNormal) {
      const into = carried.dot(surfaceNormal);
      if (into < 0) carried.addScaledVector(surfaceNormal, -into * (1 + RESTITUTION));
    }

    for (const def of DEBRIS_DEFS) {
      const mesh = new THREE.Mesh(def.geometry, def.material);
      mesh.position.copy(position).add(def.position.clone().applyEuler(rotation));
      mesh.rotation.copy(rotation);
      if (def.rotX) mesh.rotateX(def.rotX);
      mesh.castShadow = true;
      mesh.frustumCulled = false;
      this.scene.add(mesh);

      const outward = new THREE.Vector3(def.position.x, 0, def.position.z);
      if (outward.lengthSq() < 0.01) outward.set(Math.random() - 0.5, 0, Math.random() - 0.5);
      outward.normalize().applyEuler(rotation).multiplyScalar(4 + Math.random() * 7);
      const vel = carried.clone().add(outward);
      vel.y += 5 + Math.random() * 9;
      const angularVelocity = new THREE.Vector3(
        (Math.random() - 0.5) * 5, (Math.random() - 0.5) * 5, (Math.random() - 0.5) * 5,
      );
      this.debris.push({ mesh, velocity: vel, angularVelocity, settled: false });
    }

    this.flash.position.copy(position).add(new THREE.Vector3(0, 2, 0));
    this.flash.scale.setScalar(3);
    (this.flash.material as THREE.SpriteMaterial).opacity = 1;
    this.flash.visible = true;
    this.flashAge = 0;

    this.nextFireAt = 0;
    this.nextSmokeAt = 0;
    for (const p of this.smokePool) { p.active = false; p.sprite.visible = false; }
    for (const p of this.firePool) { p.active = false; p.sprite.visible = false; }
  }

  update(dt: number): void {
    if (!this.active) return;
    this.elapsed += dt;

    for (const d of this.debris) {
      if (d.settled) continue;
      d.velocity.y -= GRAVITY * dt;
      d.mesh.position.addScaledVector(d.velocity, dt);
      d.mesh.rotation.x += d.angularVelocity.x * dt;
      d.mesh.rotation.y += d.angularVelocity.y * dt;
      d.mesh.rotation.z += d.angularVelocity.z * dt;

      let touching = false;

      // Buildings, mountains and hillsides: push the chunk back out and bounce it off.
      const p = d.mesh.position;
      if (queryWorld(p.x, p.y, p.z, this.hit, DEBRIS_MARGIN)) {
        const h = this.hit;
        p.x += h.nx * h.depth;
        p.y += h.ny * h.depth;
        p.z += h.nz * h.depth;
        const into = d.velocity.x * h.nx + d.velocity.y * h.ny + d.velocity.z * h.nz;
        if (into < 0) {
          d.velocity.x -= (1 + RESTITUTION) * into * h.nx;
          d.velocity.y -= (1 + RESTITUTION) * into * h.ny;
          d.velocity.z -= (1 + RESTITUTION) * into * h.nz;
          d.velocity.multiplyScalar(SURFACE_FRICTION + 0.1);
          d.angularVelocity.multiplyScalar(0.55);
        }
        touching = true;
      }

      // Level ground.
      if (p.y <= GROUND_Y) {
        p.y = GROUND_Y;
        d.velocity.y = Math.abs(d.velocity.y) * RESTITUTION;
        d.velocity.x *= SURFACE_FRICTION;
        d.velocity.z *= SURFACE_FRICTION;
        d.angularVelocity.multiplyScalar(0.55);
        touching = true;
      }

      if (touching && d.velocity.length() < 0.5) {
        d.settled = true;
        d.velocity.set(0, 0, 0);
        d.angularVelocity.set(0, 0, 0);
      }
    }

    if (this.flash.visible) {
      this.flashAge += dt;
      const t = this.flashAge / 0.35;
      (this.flash.material as THREE.SpriteMaterial).opacity = Math.max(0, 1 - t);
      this.flash.scale.setScalar(3 + t * 11);
      if (t >= 1) this.flash.visible = false;
    }

    if (this.elapsed < 1.3) {
      this.nextFireAt -= dt;
      if (this.nextFireAt <= 0) { this.spawn(this.firePool, 'fire'); this.nextFireAt = 0.07; }
    }
    if (this.elapsed < 3.2) {
      this.nextSmokeAt -= dt;
      if (this.nextSmokeAt <= 0) { this.spawn(this.smokePool, 'smoke'); this.nextSmokeAt = 0.11; }
    }

    for (const p of this.smokePool) this.stepParticle(p, dt, 0.5);
    for (const p of this.firePool) this.stepParticle(p, dt, 1.2);

    // Wreckage that never quite comes to rest (wedged on a ledge, say) is frozen after a while.
    if (this.elapsed > MAX_WRECK_TIME) {
      for (const d of this.debris) d.settled = true;
    }
    if (this.elapsed > 8 && this.allSettled()) this.active = false;
  }

  private spawn(pool: Particle[], kind: 'fire' | 'smoke'): void {
    let target = pool.find((p) => !p.active);
    if (!target) target = pool.reduce((a, b) => (a.age / a.life > b.age / b.life ? a : b));
    target.active = true;
    target.age = 0;
    target.life = kind === 'fire' ? 0.45 + Math.random() * 0.35 : 2.2 + Math.random() * 2.6;
    target.baseOpacity = kind === 'fire' ? 0.85 : 0.5;
    target.sprite.visible = true;
    target.sprite.position.copy(this.crashPos).add(new THREE.Vector3(
      (Math.random() - 0.5) * 5, 0.5 + Math.random() * 2, (Math.random() - 0.5) * 5,
    ));
    const spread = kind === 'fire' ? 2 : 1.1;
    target.velocity.set(
      (Math.random() - 0.5) * spread,
      kind === 'fire' ? 3 + Math.random() * 3 : 1 + Math.random() * 1.6,
      (Math.random() - 0.5) * spread,
    );
    target.sprite.scale.setScalar(kind === 'fire' ? 2 + Math.random() : 1.4 + Math.random() * 1.2);
    (target.sprite.material as THREE.SpriteMaterial).opacity = target.baseOpacity;
  }

  private stepParticle(p: Particle, dt: number, growth: number): void {
    if (!p.active) return;
    p.age += dt;
    if (p.age >= p.life) {
      p.active = false;
      p.sprite.visible = false;
      return;
    }
    p.sprite.position.addScaledVector(p.velocity, dt);
    p.velocity.y *= 0.985;
    p.sprite.scale.addScalar(growth * dt);
    const fadeStart = p.life * 0.35;
    const opacity = p.age < fadeStart ? p.baseOpacity : p.baseOpacity * (1 - (p.age - fadeStart) / (p.life - fadeStart));
    (p.sprite.material as THREE.SpriteMaterial).opacity = Math.max(0, opacity);
  }

  private allSettled(): boolean {
    return this.debris.every((d) => d.settled) && this.smokePool.every((p) => !p.active) && this.firePool.every((p) => !p.active);
  }

  private clearDebris(): void {
    for (const d of this.debris) d.mesh.removeFromParent();
    this.debris = [];
  }

  /** Removes any wreckage/particles left over and stops the sequence — call on flight reset. */
  clear(): void {
    this.clearDebris();
    this.flash.visible = false;
    for (const p of this.smokePool) { p.active = false; p.sprite.visible = false; }
    for (const p of this.firePool) { p.active = false; p.sprite.visible = false; }
    this.active = false;
  }

  /** Full teardown — call when the simulation itself is disposed. */
  dispose(): void {
    this.clearDebris();
    if (this.scene) {
      this.scene.remove(this.flash);
      for (const p of this.smokePool) this.scene.remove(p.sprite);
      for (const p of this.firePool) this.scene.remove(p.sprite);
    }
    (this.flash.material as THREE.SpriteMaterial).dispose();
    for (const p of [...this.smokePool, ...this.firePool]) (p.sprite.material as THREE.SpriteMaterial).dispose();
    this.smokePool = [];
    this.firePool = [];
    this.scene = null;
  }
}
