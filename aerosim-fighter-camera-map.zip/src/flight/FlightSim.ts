import * as THREE from 'three';
import { SceneManager } from './SceneManager';
import { AircraftModel } from './AircraftModel';
import { AircraftController } from './AircraftController';
import { CameraController } from './CameraController';
import { InputManager } from './InputManager';
import { CrashEffects } from './CrashEffects';
import { AircraftType, SimulationSettings, FLAP_SETTINGS, isAircraftType } from './types';
import { AIRPORTS, airportToWorld, terrainHeight, SEA_LEVEL } from './world';
import { Multiplayer, NetState } from './Multiplayer';
import { safeDisplayName } from './nameFilter';
import { Combat, Target } from './Combat';

function makeNameSprite(text: string): THREE.Sprite {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 96;
  const ctx = canvas.getContext('2d')!;
  ctx.font = '700 44px monospace';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.lineWidth = 8;
  ctx.strokeStyle = 'rgba(0,0,0,0.75)';
  ctx.strokeText(text, 256, 48);
  ctx.fillStyle = '#7ce8e1';
  ctx.fillText(text, 256, 48);
  const tex = new THREE.CanvasTexture(canvas);
  const mat = new THREE.SpriteMaterial({ map: tex, depthTest: false, transparent: true });
  const sprite = new THREE.Sprite(mat);
  sprite.renderOrder = 999;
  sprite.frustumCulled = false;
  return sprite;
}

interface Remote {
  model: AircraftModel;
  pos: THREE.Vector3;
  quat: THREE.Quaternion;
  throttle: number;
  gear: boolean;
  crashed: boolean;
  label: THREE.Sprite;
  name: string;
  hits: number;
  target: Target;
  vel: THREE.Vector3;
  lastNet: number;
  falling: boolean;
  fallVy: number;
  fallRoll: number;
  exploded: boolean;
}


// How long after the actual ground impact to hold on the wreckage/explosion
// before showing the "YOU CRASHED" card, so the player gets to see it.
const CRASH_OVERLAY_DELAY = 2.2;
// Fallback in case impact somehow never fires (e.g. crash while already
// stationary) — never leaves the player stuck without the restart prompt.
const CRASH_OVERLAY_FALLBACK = 6;

export class FlightSim {
  private sceneManager: SceneManager;
  private aircraftModel: AircraftModel;
  private aircraftController: AircraftController;
  private cameraController: CameraController;
  private inputManager: InputManager;
  private crashEffects: CrashEffects;
  private clock = new THREE.Clock();
  private running = false;
  private rafId = 0;
  private settings: SimulationSettings;
  private telemetryTimer = 0;
  private lastCrashed = false;
  private crashTime = -1;
  private impactTime = -1;
  private mp: Multiplayer | null = null;
  private remotes = new Map<string, Remote>();
  private netTimer = 0;
  private aircraftType: AircraftType;
  private _q = new THREE.Quaternion();
  private combat: Combat;
  private kills = 0;
  private myName = 'PILOT';
  private _v = new THREE.Vector3();
  private _qq = new THREE.Quaternion();

  onStateChange?: (info: {
    throttle: number;
    airspeed: number;
    altitude: number;
    verticalSpeed: number;
    angleOfAttack: number;
    stalled: boolean;
    cameraMode: string;
    flaps: number;
    gearDown: boolean;
    gearExtension: number;
    speedbrake: number;
    reverseThrust: boolean;
    crashed: boolean;
    crashReason: string;
    showCrashOverlay: boolean;
    onGround: boolean;
    heading: number;
    bankAngle: number;
    pitchAngle: number;
    posX: number;
    posZ: number;
    yaw: number;
    kills: number;
    fighter: boolean;
    others: Array<{ id: string; name: string; x: number; z: number; yaw: number }>;
  }) => void;

  constructor(container: HTMLElement, settings: SimulationSettings, spawnAirportId?: string, aircraftType: AircraftType = 'a350', mp: Multiplayer | null = null) {
    this.settings = settings;
    this.aircraftType = aircraftType;
    this.mp = mp;
    this.sceneManager = new SceneManager(container);
    this.aircraftModel = new AircraftModel(aircraftType);
    this.sceneManager.scene.add(this.aircraftModel.group);
    void this.aircraftModel.loadModel();

    // Multiplayer: everyone shares the first airport and lines up on its runway centreline,
    // spaced out so planes don't start on top of each other.
    const airport = (mp ? AIRPORTS[0] : AIRPORTS.find((a) => a.id === spawnAirportId)) ?? AIRPORTS[0];
    const slot = mp ? Math.floor(Math.random() * 8) : 0;
    const [sx, sz] = airportToWorld(airport, 0, airport.runwayLength / 2 - 150 - slot * 60);
    this.aircraftController = new AircraftController(this.aircraftModel.group, { x: sx, z: sz, yaw: airport.yaw }, aircraftType);
    this.aircraftController.syncTransform();

    this.crashEffects = new CrashEffects();
    this.crashEffects.attach(this.sceneManager.scene);
    this.combat = new Combat(this.sceneManager.scene);
    this.combat.onDroneDown = () => { this.kills++; };
    this.combat.onHit = (id) => this.onBulletHitRemote(id);
    this.aircraftController.onImpact = (position, rotation, velocity, surfaceNormal) => {
      this.crashEffects.trigger(position, rotation, velocity, surfaceNormal);
      this.aircraftModel.group.visible = false;
      this.impactTime = 0;
    };

    this.cameraController = new CameraController(this.sceneManager.camera, () => this.aircraftModel.cameraCentreY,
      () => this.aircraftModel.cameraScale, () => this.aircraftModel.cockpitEye);
    // The fighter is small and fast, so its chase camera sits much further back to give a wider view.
    if (aircraftType === 'f16') this.cameraController.setChaseZoom(3.2);
    this.cameraController.update(this.aircraftController, 0.016);
    this.sceneManager.followShadow(this.aircraftController.state.position);

    this.inputManager = new InputManager();
    this.attachMouseLook(container);

    if (this.mp) {
      this.mp.onRemoteState = (st) => this.applyRemote(st);
      this.mp.onRemoteLeave = (id) => this.removeRemote(id);
      this.mp.onShotDown = (by) => this.aircraftController.forceCrash(`Shot down by ${by}.`);
    }
  }

  private applyRemote(st: NetState): void {
    let r = this.remotes.get(st.id);
    if (!r) {
      // Unknown aircraft types (e.g. from a different game version) fall back to the A350.
      const ac: AircraftType = isAircraftType(st.ac) ? st.ac : 'a350';
      const model = new AircraftModel(ac);
      this.sceneManager.scene.add(model.group);
      model.loadModel().catch((err) => console.warn('Remote aircraft model failed to load', err));
      r = {
        model,
        pos: new THREE.Vector3(...st.p),
        quat: new THREE.Quaternion(...st.q),
        throttle: 0, gear: true, crashed: false,
        label: makeNameSprite(safeDisplayName(st.n)),
        name: safeDisplayName(st.n),
        hits: 0,
        vel: new THREE.Vector3(),
        lastNet: performance.now(),
        falling: false, fallVy: 0, fallRoll: 0, exploded: false,
        target: { id: st.id, position: model.group.position, radius: 16, alive: true },
      };
      this.sceneManager.scene.add(r.label);
      model.group.position.copy(r.pos);
      model.group.quaternion.copy(r.quat);
      this.remotes.set(st.id, r);
    }
    const nowMs = performance.now();
    const netDt = (nowMs - r.lastNet) / 1000;
    if (!st.crashed && netDt > 0.02 && netDt < 1) {
      r.vel.set(st.p[0] - r.pos.x, st.p[1] - r.pos.y, st.p[2] - r.pos.z).divideScalar(netDt);
    }
    r.lastNet = nowMs;
    if (st.crashed && !r.crashed) {
      // Shot down (or otherwise crashed): let the plane tumble out of the sky and
      // explode when it actually reaches the ground, rather than vanishing mid-air.
      r.falling = true;
      r.exploded = false;
      r.fallVy = Math.min(r.vel.y, -12);
      r.fallRoll = 0;
      r.model.group.visible = true;
    }
    if (!st.crashed && r.crashed) { r.hits = 0; r.falling = false; r.exploded = false; }
    r.target.alive = !st.crashed;
    r.pos.set(...st.p);
    r.quat.set(...st.q);
    r.throttle = st.th;
    r.gear = st.gear;
    r.crashed = st.crashed;
    if (!st.crashed) {
      r.model.group.visible = true;
      r.label.visible = true;
    } else if (!r.falling && !r.exploded) {
      // Joined after it was already wrecked.
      r.exploded = true;
      r.model.group.visible = false;
      r.label.visible = false;
    }
  }

  /** Local crash animation for a remote plane: tumble, trail smoke, explode on impact. */
  private stepFallingRemote(r: Remote, dt: number): void {
    const g = r.model.group;
    r.fallVy -= 25 * dt;
    r.fallRoll += 2.6 * dt;
    const fwd = this._v.set(0, 0, -1).applyQuaternion(g.quaternion);
    const speed = Math.max(40, Math.hypot(r.vel.x, r.vel.z));
    g.position.x += fwd.x * speed * dt;
    g.position.z += fwd.z * speed * dt;
    g.position.y += r.fallVy * dt;
    const yaw = new THREE.Euler().setFromQuaternion(g.quaternion, 'YXZ').y;
    g.rotation.set(Math.min(0.9, -r.fallVy / 110), yaw, r.fallRoll, 'YXZ');
    this.combat.smokeAt(g.position);
    const ground = Math.max(terrainHeight(g.position.x, g.position.z), SEA_LEVEL);
    if (g.position.y <= ground + 3.5) {
      r.falling = false;
      r.exploded = true;
      g.visible = false;
      r.label.visible = false;
      this.combat.explode(g.position.clone(), g.rotation.clone(), new THREE.Vector3(fwd.x * speed * 0.5, r.fallVy, fwd.z * speed * 0.5));
    }
  }

  private onBulletHitRemote(id: string): void {
    const r = this.remotes.get(id);
    if (!r || r.crashed) return;
    r.hits++;
    if (r.hits >= 10) {
      r.hits = 0;
      this.kills++;
      this.mp?.sendKill(id);
    }
  }

  private removeRemote(id: string): void {
    const r = this.remotes.get(id);
    if (!r) return;
    this.sceneManager.scene.remove(r.model.group);
    this.sceneManager.scene.remove(r.label);
    (r.label.material.map as THREE.Texture | null)?.dispose();
    r.label.material.dispose();
    this.remotes.delete(id);
  }

  private updateRemotes(dt: number): void {
    const k = 1 - Math.exp(-12 * dt);
    this.remotes.forEach((r) => {
      if (r.falling) {
        this.stepFallingRemote(r, dt);
      } else if (!r.exploded) {
        r.model.group.position.lerp(r.pos, k);
        r.model.group.quaternion.slerp(r.quat, k);
      }
      if (r.exploded) return;
      try {
        r.model.updateAnimation(0, 0, 0, r.throttle, dt, r.gear ? 1 : 0, 0);
      } catch (err) {
        console.warn('Remote aircraft animation error', err);
      }
      // Name tag floats above the plane and keeps a roughly constant size on screen.
      r.label.position.copy(r.model.group.position);
      r.label.position.y += 14;
      const dist = r.label.position.distanceTo(this.sceneManager.camera.position);
      const h = Math.min(Math.max(dist * 0.035, 3), 400);
      r.label.scale.set(h * (512 / 96), h, 1);
    });
  }

  /** Live remote players (not wrecked) as map positions, for the minimap. */
  private getOtherPlayers(): Array<{ id: string; name: string; x: number; z: number; yaw: number }> {
    const out: Array<{ id: string; name: string; x: number; z: number; yaw: number }> = [];
    this.remotes.forEach((r, id) => {
      if (r.crashed || r.falling || r.exploded) return;
      const p = r.model.group.position;
      this._v.set(0, 0, -1).applyQuaternion(r.model.group.quaternion);
      out.push({ id, name: r.name, x: p.x, z: p.z, yaw: Math.atan2(-this._v.x, -this._v.z) });
    });
    return out;
  }

  private sendNet(dt: number): void {
    if (!this.mp) return;
    this.netTimer += dt;
    if (this.netTimer < 1 / 8) return;
    this.netTimer = 0;
    const s = this.aircraftController.state;
    this._q.setFromEuler(s.rotation);
    this.mp.sendState({
      id: this.mp.myId,
      ac: this.aircraftType,
      p: [s.position.x, s.position.y, s.position.z],
      q: [this._q.x, this._q.y, this._q.z, this._q.w],
      th: s.throttle,
      gear: s.gearDown,
      crashed: s.crashed,
    });
  }

  private attachMouseLook(container: HTMLElement): void {
    let dragging = false;
    let lastX = 0;
    let lastY = 0;
    container.style.cursor = 'grab';

    const move = (e: MouseEvent) => {
      if (!dragging) return;
      this.cameraController.lookAround(e.clientX - lastX, e.clientY - lastY);
      lastX = e.clientX;
      lastY = e.clientY;
    };
    const up = () => {
      dragging = false;
      container.style.cursor = 'grab';
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
    };
    const down = (e: MouseEvent) => {
      dragging = true;
      lastX = e.clientX;
      lastY = e.clientY;
      container.style.cursor = 'grabbing';
      window.addEventListener('mousemove', move);
      window.addEventListener('mouseup', up);
    };
    container.addEventListener('mousedown', down);
    this.disposeMouseLook = () => {
      container.removeEventListener('mousedown', down);
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
    };
  }

  private disposeMouseLook: () => void = () => {};

  start(): void {
    if (this.running) return;
    this.running = true;
    this.inputManager.attach();
    this.clock.start();
    this.loop();
  }

  stop(): void {
    this.running = false;
    this.inputManager.detach();
    cancelAnimationFrame(this.rafId);
  }

  resetFlight(): void {
    this.aircraftController.reset();
    this.crashEffects.clear();
    this.combat.clearEffects();
    this.aircraftModel.group.visible = true;
    this.crashTime = -1;
    this.impactTime = -1;
    this.cameraController.snap();
    this.cameraController.update(this.aircraftController, 0.016);
  }

  setSettings(settings: SimulationSettings): void {
    this.settings = settings;
  }

  private loop = (): void => {
    if (!this.running) return;
    this.rafId = requestAnimationFrame(this.loop);

    const dt = Math.min(this.clock.getDelta(), 0.05);
    const input = this.inputManager.getState();

    // Camera toggle
    if (this.inputManager.consumeJustPressed('cameraToggle')) {
      this.cameraController.toggleMode();
    }

    // Reset
    if (this.inputManager.consumeJustPressed('reset')) {
      this.resetFlight();
    }

    // Flaps
    if (this.inputManager.consumeJustPressed('flapsDown')) {
      this.aircraftController.state.flaps = Math.min(3, this.aircraftController.state.flaps + 1);
    }
    if (this.inputManager.consumeJustPressed('flapsUp')) {
      this.aircraftController.state.flaps = Math.max(0, this.aircraftController.state.flaps - 1);
    }

    // Speed brakes
    if (this.inputManager.consumeJustPressed('speedbrakeToggle')) {
      this.aircraftController.state.speedbrake = !this.aircraftController.state.speedbrake;
    }
    {
      const st = this.aircraftController.state;
      st.speedbrakeExtension = THREE.MathUtils.damp(st.speedbrakeExtension, st.speedbrake ? 1 : 0, 3, dt);
    }

    // Gear toggle
    if (this.inputManager.consumeJustPressed('gearToggle')) {
      this.aircraftController.state.gearDown = !this.aircraftController.state.gearDown;
    }

    this.aircraftController.update(input, dt);

    // Animate aircraft parts
    this.aircraftModel.updateAnimation(
      this.aircraftController.state.roll,
      this.aircraftController.state.pitch,
      this.aircraftController.state.yaw,
      this.aircraftController.state.throttle,
      dt,
      this.aircraftController.state.gearDown ? 1 : 0,
      this.aircraftController.state.flaps / 3,
    );
    this.aircraftController.state.gearExtension = this.aircraftModel.gearExtension;

    // Guns (fighter only) and bullets
    {
      const st = this.aircraftController.state;
      this._qq.setFromEuler(st.rotation);
      const canFire = this.aircraftType === 'f16' && !st.crashed;
      this.combat.tryFire(st.position, this._qq, st.velocity, dt, canFire && input.fire);
      const targets: Target[] = [];
      this.remotes.forEach((r) => {
        if (!r.crashed) targets.push(r.target);
        if (r.hits >= 4 && !r.crashed) this.combat.smokeAt(r.model.group.position);
      });
      if (st.crashed && this.impactTime < 0) this.combat.smokeAt(st.position);
      this.combat.update(dt, targets);
    }

    this.updateRemotes(dt);
    this.sendNet(dt);
    this.crashEffects.update(dt);
    this.cameraController.update(this.aircraftController, dt);
    this.sceneManager.followShadow(this.aircraftController.state.position);
    this.sceneManager.render();

    // Push telemetry to the React HUD ~20 times a second instead of every frame.
    this.telemetryTimer += dt;
    const crashed = this.aircraftController.state.crashed;
    if (crashed) {
      this.crashTime = this.crashTime < 0 ? 0 : this.crashTime + dt;
    } else {
      this.crashTime = -1;
    }
    if (this.impactTime >= 0) this.impactTime += dt;
    const showCrashOverlay = crashed && (
      (this.impactTime >= 0 && this.impactTime >= CRASH_OVERLAY_DELAY) ||
      this.crashTime >= CRASH_OVERLAY_FALLBACK
    );
    if (this.onStateChange && (this.telemetryTimer >= 0.05 || crashed !== this.lastCrashed)) {
      this.telemetryTimer = 0;
      this.lastCrashed = crashed;
      this.onStateChange({
        throttle: this.aircraftController.state.throttle,
        airspeed: this.aircraftController.state.airspeed,
        altitude: this.aircraftController.state.position.y,
        verticalSpeed: this.aircraftController.state.verticalSpeed,
        angleOfAttack: this.aircraftController.state.angleOfAttack,
        stalled: this.aircraftController.state.stalled,
        cameraMode: this.cameraController.getMode(),
        flaps: this.aircraftController.state.flaps,
        gearDown: this.aircraftController.state.gearDown,
        gearExtension: this.aircraftController.state.gearExtension,
        speedbrake: this.aircraftController.state.speedbrakeExtension,
        reverseThrust: this.aircraftController.state.reverseThrust,
        crashed: this.aircraftController.state.crashed,
        crashReason: this.aircraftController.state.crashReason,
        showCrashOverlay,
        onGround: this.aircraftController.state.onGround,
        heading: this.aircraftController.state.heading,
        bankAngle: this.aircraftController.state.bankAngle,
        pitchAngle: this.aircraftController.state.pitchAngle,
        posX: this.aircraftController.state.position.x,
        posZ: this.aircraftController.state.position.z,
        yaw: this.aircraftController.state.rotation.y,
        kills: this.kills,
        fighter: this.aircraftType === 'f16',
        others: this.getOtherPlayers(),
      });
    }
  };

  dispose(): void {
    this.remotes.forEach((_, id) => this.removeRemote(id));
    this.mp?.dispose();
    this.disposeMouseLook();
    this.stop();
    this.crashEffects.dispose();
    this.combat.dispose();
    this.sceneManager.dispose();
  }
}
