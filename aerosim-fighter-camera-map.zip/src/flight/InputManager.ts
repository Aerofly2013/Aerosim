import { InputState } from './types';

const KEY_MAP: Record<string, keyof InputState> = {
  KeyW: 'pitchDown',
  KeyS: 'pitchUp',
  KeyA: 'rollLeft',
  KeyD: 'rollRight',
  KeyQ: 'yawLeft',
  KeyE: 'yawRight',
  ArrowUp: 'pitchUp',
  ArrowDown: 'pitchDown',
  ArrowLeft: 'rollLeft',
  ArrowRight: 'rollRight',
  ShiftLeft: 'throttleUp',
  ShiftRight: 'throttleUp',
  ControlLeft: 'throttleDown',
  ControlRight: 'throttleDown',
  KeyZ: 'throttleDown',
  KeyX: 'throttleUp',
  KeyC: 'cameraToggle',
  KeyR: 'reset',
  KeyF: 'flapsDown',
  KeyG: 'flapsUp',
  KeyV: 'gearToggle',
  KeyB: 'speedbrakeToggle',
  KeyM: 'reverseThrust',
  Space: 'fire',
};

export class InputManager {
  private state: InputState = {
    throttleUp: false,
    throttleDown: false,
    pitchUp: false,
    pitchDown: false,
    rollLeft: false,
    rollRight: false,
    yawLeft: false,
    yawRight: false,
    cameraToggle: false,
    reset: false,
    flapsUp: false,
    flapsDown: false,
    gearToggle: false,
    speedbrakeToggle: false,
    reverseThrust: false,
    fire: false,
  };

  private justPressed = new Set<keyof InputState>();
  private enabled = false;

  private onKeyDown = (e: KeyboardEvent) => {
    const action = KEY_MAP[e.code];
    if (!action) return;
    e.preventDefault();
    if (!this.state[action]) {
      this.justPressed.add(action);
    }
    this.state[action] = true;
  };

  private onKeyUp = (e: KeyboardEvent) => {
    const action = KEY_MAP[e.code];
    if (!action) return;
    e.preventDefault();
    this.state[action] = false;
  };

  attach(): void {
    if (this.enabled) return;
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    this.enabled = true;
  }

  detach(): void {
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    this.enabled = false;
  }

  getState(): InputState {
    return { ...this.state };
  }

  consumeJustPressed(action: keyof InputState): boolean {
    const pressed = this.justPressed.has(action);
    this.justPressed.delete(action);
    return pressed;
  }

  reset(): void {
    this.state = {
      throttleUp: false,
      throttleDown: false,
      pitchUp: false,
      pitchDown: false,
      rollLeft: false,
      rollRight: false,
      yawLeft: false,
      yawRight: false,
      cameraToggle: false,
      reset: false,
      flapsUp: false,
      flapsDown: false,
      gearToggle: false,
      speedbrakeToggle: false,
      reverseThrust: false,
      fire: false,
    };
    this.justPressed.clear();
  }
}
