import { initializeApp } from 'firebase/app';
import {
  getDatabase, ref, set, get, remove, onDisconnect, onValue,
  onChildAdded, onChildChanged, onChildRemoved,
  type Database, type Unsubscribe,
} from 'firebase/database';
import type { AircraftType } from './types';

export interface NetState {
  id: string;
  ac: AircraftType;
  n?: string;
  p: [number, number, number];
  q: [number, number, number, number];
  th: number;
  gear: boolean;
  crashed: boolean;
}

/** Everyone shares this single server. */
export const GLOBAL_SERVER = 'MAIN';

// A player who sends nothing for this long is treated as gone (closed tab, lost connection, crash).
const STALE_MS = 8000;
// Re-send our state this often even when idle/backgrounded, so we never look stale while alive.
const HEARTBEAT_MS = 2000;
// Entries already this old when we first see them are leftover ghosts from earlier sessions.
const GHOST_AGE_MS = 20000;

const makePlayerId = (): string => Math.random().toString(36).slice(2, 10);

const r = (n: number, d: number) => Math.round(n * 10 ** d) / 10 ** d;

/**
 * Multiplayer over Firebase Realtime Database (free Spark plan).
 * Uses secure WebSocket on port 443 with automatic HTTPS long-polling fallback,
 * so it works on most school networks. No server code needed.
 *
 * Each player writes their state to rooms/MAIN/players/<id> and listens to the others.
 * Ghost planes are prevented three ways: onDisconnect cleanup (re-armed after every
 * reconnect), a best-effort remove when the page closes, and a heartbeat timeout that
 * drops (and deletes) any player who has gone quiet.
 */
export class Multiplayer {
  readonly myId = makePlayerId();
  private db!: Database;
  private unsubs: Unsubscribe[] = [];
  private meRef!: ReturnType<typeof ref>;
  private playersRef!: ReturnType<typeof ref>;
  private readonly code = GLOBAL_SERVER;
  private readonly name: string;
  private lastSeen = new Map<string, number>();
  private lastState: NetState | null = null;
  private timers: number[] = [];
  private disposed = false;

  onRemoteState?: (s: NetState) => void;
  onRemoteLeave?: (id: string) => void;
  /** Another player shot us down; argument is their name. */
  onShotDown?: (by: string) => void;

  constructor(name: string) {
    this.name = name;
  }

  async connect(): Promise<void> {
    const env = import.meta.env;
    if (!env.VITE_FIREBASE_DATABASE_URL) {
      throw new Error('Multiplayer is not configured (missing Firebase environment variables).');
    }
    const app = initializeApp({
      apiKey: env.VITE_FIREBASE_API_KEY,
      projectId: env.VITE_FIREBASE_PROJECT_ID,
      databaseURL: env.VITE_FIREBASE_DATABASE_URL,
    }, 'aerosim-' + this.myId);
    this.db = getDatabase(app);

    this.playersRef = ref(this.db, `rooms/${this.code}/players`);
    try {
      await Promise.race([
        get(this.playersRef),
        new Promise<never>((_, rej) => setTimeout(() => rej(new Error('timeout')), 10000)),
      ]);
    } catch {
      throw new Error('Could not reach the multiplayer server. The network may be blocking it.');
    }

    this.meRef = ref(this.db, `rooms/${this.code}/players/${this.myId}`);

    // onDisconnect is one-shot on the server, so re-arm it every time we (re)connect.
    this.unsubs.push(
      onValue(ref(this.db, '.info/connected'), (snap) => {
        if (snap.val() === true) void onDisconnect(this.meRef).remove();
      }),
    );

    const handle = (snap: { key: string | null; val: () => unknown }, isAdd: boolean) => {
      if (!snap.key || snap.key === this.myId) return;
      const v = snap.val() as (Omit<NetState, 'id'> & { t?: number }) | null;
      if (!v) return;
      // A brand-new entry that is already old is a ghost left behind by a dead session.
      if (isAdd && typeof v.t === 'number' && Date.now() - v.t > GHOST_AGE_MS) {
        void remove(ref(this.db, `rooms/${this.code}/players/${snap.key}`));
        return;
      }
      this.lastSeen.set(snap.key, Date.now());
      this.onRemoteState?.({ ...v, id: snap.key });
    };
    this.unsubs.push(
      onChildAdded(this.playersRef, (s) => handle(s, true)),
      onChildChanged(this.playersRef, (s) => handle(s, false)),
      onChildRemoved(this.playersRef, (snap) => {
        if (!snap.key) return;
        this.lastSeen.delete(snap.key);
        this.onRemoteLeave?.(snap.key);
      }),
    );

    // Listen for kill messages addressed to us.
    const hitRef = ref(this.db, `rooms/${this.code}/hits/${this.myId}`);
    this.unsubs.push(
      onValue(hitRef, (snap) => {
        const v = snap.val() as { by?: string; t?: number } | null;
        if (!v) return;
        void remove(hitRef);
        if (typeof v.t === 'number' && Date.now() - v.t > 10000) return;
        this.onShotDown?.(String(v.by ?? 'another pilot').slice(0, 16));
      }),
    );

    // Drop anyone who has stopped sending, and clean their entry out of the database.
    this.timers.push(window.setInterval(() => {
      const now = Date.now();
      this.lastSeen.forEach((seen, id) => {
        if (now - seen > STALE_MS) {
          this.lastSeen.delete(id);
          this.onRemoteLeave?.(id);
          void remove(ref(this.db, `rooms/${this.code}/players/${id}`));
        }
      });
    }, 2000));

    // Heartbeat: keeps us alive in others' eyes even when this tab is idle or in the background.
    this.timers.push(window.setInterval(() => this.write(), HEARTBEAT_MS));

    window.addEventListener('pagehide', this.onPageHide);
  }

  private onPageHide = () => {
    if (this.meRef) void remove(this.meRef);
  };

  private write(): void {
    const s = this.lastState;
    if (!s || !this.meRef || this.disposed) return;
    void set(this.meRef, {
      n: this.name,
      ac: s.ac,
      p: s.p.map((n) => r(n, 1)),
      q: s.q.map((n) => r(n, 4)),
      th: r(s.th, 2),
      gear: s.gear,
      crashed: s.crashed,
      t: Date.now(), // changes every write, so idle players still produce a heartbeat
    });
  }

  sendState(s: NetState): void {
    this.lastState = s;
    this.write();
  }

  /** Tell a player they have been shot down. */
  sendKill(victimId: string): void {
    if (this.disposed || !this.db) return;
    void set(ref(this.db, `rooms/${this.code}/hits/${victimId}`), { by: this.name, t: Date.now() });
  }

  dispose(): void {
    this.disposed = true;
    window.removeEventListener('pagehide', this.onPageHide);
    this.timers.forEach((t) => window.clearInterval(t));
    this.timers = [];
    this.unsubs.forEach((u) => u());
    this.unsubs = [];
    this.lastSeen.clear();
    if (this.meRef) void remove(this.meRef);
  }
}
