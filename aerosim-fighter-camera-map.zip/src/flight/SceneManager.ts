import * as THREE from 'three';
import {
  AIRPORTS, AirportDef, CITY, CITY_BLOCKS, CITY_TOWERS, MOUNTAINS, MOUNTAIN_SIDES, SEA_LEVEL, TREES,
  TERRAIN_CENTER_X, TERRAIN_CENTER_Z, TERRAIN_COLORS, TERRAIN_HEIGHTS, TERRAIN_SEGMENTS, TERRAIN_SIZE,
  airportStructures, terrainHeight,
} from './world';

const SUN_OFFSET = new THREE.Vector3(-600, 900, 400);

export class SceneManager {
  scene: THREE.Scene;
  renderer: THREE.WebGLRenderer;
  camera: THREE.PerspectiveCamera;
  private sun: THREE.DirectionalLight;
  private sunVisuals: THREE.Object3D[] = [];
  private sunVisualOffset = new THREE.Vector3(-1400, 1100, -3800);
  private resizeHandler: () => void;

  constructor(container: HTMLElement) {
    this.scene = new THREE.Scene();
    this.renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: 'high-performance',
      // A 0.1 m near plane against a 60 km far plane z-fights badly (the flashing ground); log depth fixes it.
      logarithmicDepthBuffer: true,
    });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    container.appendChild(this.renderer.domElement);
    this.camera = new THREE.PerspectiveCamera(62, window.innerWidth / window.innerHeight, 0.1, 60000);

    this.sun = new THREE.DirectionalLight(0xfff2d6, 2.6);
    this.setupLighting();
    this.setupAtmosphere();
    this.setupWorld();
    this.resizeHandler = () => this.onResize();
    window.addEventListener('resize', this.resizeHandler);
  }

  private setupLighting(): void {
    this.scene.add(new THREE.HemisphereLight(0x9fd0f5, 0x2a3a20, 1.2));

    // Shadows only need to cover the area around the aircraft, so a small
    // frustum follows it (see followShadow) instead of one huge map.
    this.sun.position.copy(SUN_OFFSET);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(2048, 2048);
    this.sun.shadow.camera.near = 100;
    this.sun.shadow.camera.far = 2200;
    this.sun.shadow.camera.left = -160;
    this.sun.shadow.camera.right = 160;
    this.sun.shadow.camera.top = 160;
    this.sun.shadow.camera.bottom = -160;
    this.sun.shadow.bias = -0.0004;
    this.sun.shadow.normalBias = 0.05;
    this.scene.add(this.sun);
    this.scene.add(this.sun.target);

    // Fill light from opposite side
    const fill = new THREE.DirectionalLight(0x6090c0, 0.4);
    fill.position.set(800, 500, -600);
    this.scene.add(fill);
  }

  private setupAtmosphere(): void {
    this.scene.background = new THREE.Color(0x7bb8e8);
    this.scene.fog = new THREE.Fog(0x9cc4e8, 3000, 34000);

    // Sun disc
    const sunDisc = new THREE.Mesh(
      new THREE.SphereGeometry(120, 24, 24),
      new THREE.MeshBasicMaterial({ color: 0xfff8e0, transparent: true, opacity: 0.95 }),
    );
    sunDisc.position.copy(this.sunVisualOffset);
    this.scene.add(sunDisc);

    // Atmospheric glow around sun
    const glowGeo = new THREE.SphereGeometry(300, 24, 24);
    const glowMat = new THREE.MeshBasicMaterial({
      color: 0xfff5d0, transparent: true, opacity: 0.15,
      blending: THREE.AdditiveBlending, depthWrite: false,
    });
    const glow = new THREE.Mesh(glowGeo, glowMat);
    glow.position.copy(sunDisc.position);
    this.scene.add(glow);
    this.sunVisuals = [sunDisc, glow];

    this.addCloudLayer();
  }

  private addCloudLayer(): void {
    const clouds = new THREE.Group();
    const cloudMat = new THREE.MeshStandardMaterial({
      color: 0xffffff, roughness: 1, transparent: true,
      opacity: 0.82, depthWrite: false,
    });
    const cloudGeo = new THREE.SphereGeometry(1, 12, 10);
    // Clouds drift over the whole archipelago (a fixed pseudo-random scatter, same every run).
    const positions: Array<[number, number, number, number, number]> = [];
    let seed = 91;
    const rand = () => { seed = (seed * 48271) % 2147483647; return seed / 2147483647; };
    for (let n = 0; n < 46; n++) {
      positions.push([
        -12000 + rand() * 30000, 750 + rand() * 600, -17000 + rand() * 24000,
        220 + rand() * 260, 70 + rand() * 70,
      ]);
    }
    for (const [x, y, z, scale, height] of positions) {
      const cloud = new THREE.Mesh(cloudGeo, cloudMat);
      cloud.position.set(x, y, z);
      cloud.scale.set(scale, height, scale * 0.6);
      clouds.add(cloud);
    }
    this.scene.add(clouds);
  }

  private setupWorld(): void {
    // Island terrain. Heights and colours come from world.ts (level ground around every airport and
    // the city, a shallow shelf and then deep water offshore) so the collision code sees exactly this surface.
    // Pushed back slightly so runway slabs and aprons lying on the flat ground always win the depth test.
    const terrainMat = new THREE.MeshStandardMaterial({
      vertexColors: true, roughness: 1, polygonOffset: true, polygonOffsetFactor: 2, polygonOffsetUnits: 2,
    });
    const geo = new THREE.PlaneGeometry(TERRAIN_SIZE, TERRAIN_SIZE, TERRAIN_SEGMENTS, TERRAIN_SEGMENTS);
    const pos = geo.attributes.position;
    for (let i = 0; i < pos.count; i++) pos.setZ(i, TERRAIN_HEIGHTS[i]);
    // Vertex colours are authored as sRGB; the renderer wants them in linear space.
    const linear = new Float32Array(TERRAIN_COLORS.length);
    const tmp = new THREE.Color();
    for (let i = 0; i < TERRAIN_COLORS.length; i += 3) {
      tmp.setRGB(TERRAIN_COLORS[i], TERRAIN_COLORS[i + 1], TERRAIN_COLORS[i + 2], THREE.SRGBColorSpace);
      linear[i] = tmp.r; linear[i + 1] = tmp.g; linear[i + 2] = tmp.b;
    }
    geo.setAttribute('color', new THREE.BufferAttribute(linear, 3));
    geo.computeVertexNormals();
    const terrain = new THREE.Mesh(geo, terrainMat);
    terrain.rotation.x = -Math.PI / 2;
    terrain.position.set(TERRAIN_CENTER_X, 0, TERRAIN_CENTER_Z);
    terrain.receiveShadow = true;
    this.scene.add(terrain);

    // The ocean: one big translucent sheet, so the sea floor shows through as lighter shallows near the coast.
    const water = new THREE.Mesh(
      new THREE.PlaneGeometry(240000, 240000),
      new THREE.MeshStandardMaterial({
        color: 0x1d78a6, roughness: 0.18, metalness: 0.05, transparent: true, opacity: 0.8,
      }),
    );
    water.rotation.x = -Math.PI / 2;
    water.position.set(TERRAIN_CENTER_X, SEA_LEVEL, TERRAIN_CENTER_Z);
    water.receiveShadow = true;
    this.scene.add(water);

    this.addMountainRidges();
    for (const def of AIRPORTS) this.addAirport(def, def.full);
    this.addCity();
    this.addTreeClusters();
  }

  private addMountainRidges(): void {
    const mountainMat = new THREE.MeshStandardMaterial({
      color: 0x3f574c, roughness: 1,
    });
    for (const m of MOUNTAINS) {
      const mountain = new THREE.Mesh(
        new THREE.ConeGeometry(m.radius, m.height, MOUNTAIN_SIDES),
        mountainMat,
      );
      mountain.position.set(m.x, m.centreY, m.z);
      mountain.rotation.y = m.yaw;
      this.scene.add(mountain);
    }
  }

  /** Draws many copies of one shape in a single draw call. */
  private instances(parent: THREE.Object3D, geo: THREE.BufferGeometry, mat: THREE.Material, pts: Array<[number, number, number]>): void {
    const mesh = new THREE.InstancedMesh(geo, mat, pts.length);
    const m = new THREE.Matrix4();
    pts.forEach(([x, y, z], i) => mesh.setMatrixAt(i, m.makeTranslation(x, y, z)));
    mesh.instanceMatrix.needsUpdate = true;
    mesh.frustumCulled = false;
    parent.add(mesh);
  }

  private addAirport(def: AirportDef, full: boolean): void {
    const airport = new THREE.Group();
    airport.position.set(def.x, 0, def.z);
    airport.rotation.y = def.yaw;
    const L = def.runwayLength;
    const asphalt = new THREE.MeshStandardMaterial({ color: 0x252b2d, roughness: 0.95 });
    const concrete = new THREE.MeshStandardMaterial({ color: 0x5b6462, roughness: 0.9 });
    const white = new THREE.MeshBasicMaterial({ color: 0xf5f0d8 });
    const yellow = new THREE.MeshBasicMaterial({ color: 0xffc52d });
    const glass = new THREE.MeshStandardMaterial({ color: 0x214e68, metalness: 0.5, roughness: 0.18 });
    const hangarMat = new THREE.MeshStandardMaterial({ color: 0x707978, roughness: 0.8 });
    const terminalMat = new THREE.MeshStandardMaterial({
      color: full ? 0xc6c9c4 : 0x9cc3d3, roughness: 0.6, metalness: 0.2,
    });
    const box = (w: number, h: number, d: number, mat: THREE.Material, x: number, y: number, z: number, shadow = false, receive = false) => {
      const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
      m.position.set(x, y, z);
      m.castShadow = shadow;
      m.receiveShadow = receive;
      airport.add(m);
    };

    // Terminal and hangars come from the shared world data, so what is drawn is exactly what can be hit.
    for (const b of airportStructures(full)) {
      box(b.w, b.h, b.d, b.kind === 'terminal' ? terminalMat : hangarMat, b.x, b.h / 2, b.z, true);
    }

    // Runway, centre line and threshold markings
    box(90, 0.12, L, asphalt, 0, 0.05, 0, false, true);
    const centre: Array<[number, number, number]> = [];
    for (let z = -L / 2 + 50; z < L / 2 - 50; z += 70) centre.push([0, 0.13, z]);
    this.instances(airport, new THREE.BoxGeometry(2, 0.03, 32), white, centre);
    const thresholds: Array<[number, number, number]> = [];
    for (const z of [-(L / 2 - 100), L / 2 - 100]) for (const x of [-28, 28]) thresholds.push([x, 0.13, z]);
    this.instances(airport, new THREE.BoxGeometry(4, 0.03, 44), white, thresholds);

    // Runway edge lights (one draw call) and approach masts
    const edge: Array<[number, number, number]> = [];
    for (let z = -L / 2 + 50; z <= L / 2 - 50; z += 100) for (const x of [-46, 46]) edge.push([x, 0.5, z]);
    this.instances(airport, new THREE.SphereGeometry(0.4, 6, 6), new THREE.MeshBasicMaterial({ color: 0xffe4a3 }), edge);
    const masts: Array<[number, number, number]> = [];
    for (const x of [-44, 44]) for (const z of [-(L / 2 - 150), L / 2 - 150]) masts.push([x, 5, z]);
    this.instances(airport, new THREE.CylinderGeometry(0.5, 0.5, 10, 6), new THREE.MeshStandardMaterial({ color: 0x9b9d99, metalness: 0.7 }), masts);
    this.instances(airport, new THREE.SphereGeometry(0.9, 6, 6), new THREE.MeshBasicMaterial({ color: 0xffb347 }),
      masts.map(([x, , z]) => [x, 10.5, z] as [number, number, number]));

    if (full) {
      box(500, 0.08, 300, concrete, 300, 0.04, 250, false, true);
      const taxiXs = [70, 170, 270, 370, 470];
      taxiXs.forEach((x) => box(12, 0.1, 300, asphalt, x, 0.1, 250));
      const marks: Array<[number, number, number]> = [];
      for (const x of taxiXs) for (let z = 120; z < 390; z += 45) marks.push([x, 0.17, z]);
      this.instances(airport, new THREE.BoxGeometry(0.8, 0.03, 18), yellow, marks);
      const windows: Array<[number, number, number]> = [];
      for (let x = 190; x <= 410; x += 44) windows.push([x, 18, 481]);
      this.instances(airport, new THREE.BoxGeometry(28, 15, 0.8), glass, windows);
      this.instances(airport, new THREE.BoxGeometry(58, 19, 1), glass, [100, 250, 400, 550].map((x) => [x, 10, -269] as [number, number, number]));
      this.addAirportVehicles(airport);
    } else {
      // Smaller regional field
      box(260, 0.08, 140, concrete, 200, 0.04, 150, false, true);
      box(100, 0.1, 14, asphalt, 95, 0.1, 150);
      this.instances(airport, new THREE.BoxGeometry(24, 12, 0.8), glass, [150, 200, 250].map((x) => [x, 15, 234.6] as [number, number, number]));
      this.instances(airport, new THREE.BoxGeometry(48, 16, 1), glass, [130, 270].map((x) => [x, 8, -64.5] as [number, number, number]));
    }
    this.scene.add(airport);
  }

  private addAirportVehicles(parent: THREE.Group): void {
    const vehicleMat = new THREE.MeshStandardMaterial({ color: 0xd1a625, roughness: 0.7 });
    const cabinMat = new THREE.MeshStandardMaterial({ color: 0x244351, roughness: 0.3 });
    const spots: Array<[number, number, number]> = [[180, 0, 270], [250, 0, 210], [350, 0, 300], [420, 0, 235]];
    this.instances(parent, new THREE.BoxGeometry(14, 5, 7), vehicleMat, spots.map(([x, , z]) => [x, 3, z]));
    this.instances(parent, new THREE.BoxGeometry(7, 3, 6), cabinMat, spots.map(([x, , z]) => [x - 1, 6, z]));
  }

  /** A compact skyline of instanced boxes — cheap to draw, easy to spot from the air. */
  private addCity(): void {
    const city = new THREE.Group();
    city.position.set(CITY.x, 0, CITY.z);

    const blockMat = new THREE.MeshStandardMaterial({ color: 0x7d8892, roughness: 0.75 });
    const towerMat = new THREE.MeshStandardMaterial({ color: 0x93a4ad, roughness: 0.55, metalness: 0.15 });
    const windowMat = new THREE.MeshBasicMaterial({ color: 0xffd98a });
    const roadMat = new THREE.MeshStandardMaterial({ color: 0x2c2f31, roughness: 0.95 });

    // Street grid
    const roadGeoNS = new THREE.PlaneGeometry(14, CITY.radius * 2);
    const roadGeoEW = new THREE.PlaneGeometry(CITY.radius * 2, 14);
    for (let i = -3; i <= 3; i++) {
      const r1 = new THREE.Mesh(roadGeoNS, roadMat);
      r1.rotation.x = -Math.PI / 2;
      r1.position.set(i * 180, 0.06, 0);
      r1.receiveShadow = true;
      city.add(r1);
      const r2 = new THREE.Mesh(roadGeoEW, roadMat);
      r2.rotation.x = -Math.PI / 2;
      r2.position.set(0, 0.05, i * 180);
      r2.receiveShadow = true;
      city.add(r2);
    }

    // Buildings come from world.ts (the same boxes the collision code uses) and are drawn as
    // instanced meshes (block towers, slender towers, window strips) instead of hundreds of objects.
    const blocks = CITY_BLOCKS;
    const towers = CITY_TOWERS;
    const place = (defs: Array<[number, number, number, number, number]>, mat: THREE.Material) => {
      const mesh = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), mat, defs.length);
      const m = new THREE.Matrix4();
      defs.forEach(([x, z, w, d, h], i) => {
        m.compose(
          new THREE.Vector3(x, h / 2, z),
          new THREE.Quaternion(),
          new THREE.Vector3(w, h, d),
        );
        mesh.setMatrixAt(i, m);
      });
      mesh.instanceMatrix.needsUpdate = true;
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      mesh.frustumCulled = false;
      city.add(mesh);
    };
    place(blocks, blockMat);
    place(towers, towerMat);

    // A scattering of lit windows on the tallest towers, so the city reads from above at night too.
    const windows: Array<[number, number, number]> = [];
    for (const [x, z, w, , h] of towers) {
      for (let y = 14; y < h - 6; y += 16) {
        windows.push([x + w / 2 + 0.3, y, z + (((y * 7) % w) - w / 2)]);
        windows.push([x - w / 2 - 0.3, y, z - (((y * 5) % w) - w / 2)]);
      }
    }
    this.instances(city, new THREE.BoxGeometry(0.6, 3, 3), windowMat, windows);

    this.scene.add(city);
  }

  private addTreeClusters(): void {
    // Two instanced meshes (trunks + crowns) instead of thousands of separate objects.
    const spots = TREES.map(([x, z, i]) => ({ x, z, i, y: Math.max(0, terrainHeight(x, z)) }));
    const trunks = new THREE.InstancedMesh(
      new THREE.CylinderGeometry(1.3, 2.2, 12, 6),
      new THREE.MeshStandardMaterial({ color: 0x4a2f1e, roughness: 1 }), spots.length);
    const crowns = new THREE.InstancedMesh(
      new THREE.ConeGeometry(1, 1, 7),
      new THREE.MeshStandardMaterial({ color: 0x254e2b, roughness: 1 }), spots.length);
    const m = new THREE.Matrix4();
    const q = new THREE.Quaternion();
    spots.forEach(({ x, z, i, y }, n) => {
      const s = 0.65 + (i % 4) * 0.13;
      const r = (12 + (i % 5) * 2) * s;
      const h = (30 + (i % 4) * 4) * s;
      trunks.setMatrixAt(n, m.compose(new THREE.Vector3(x, y + 6 * s, z), q, new THREE.Vector3(s, s, s)));
      crowns.setMatrixAt(n, m.compose(new THREE.Vector3(x, y + 25 * s, z), q, new THREE.Vector3(r, h, r)));
    });
    for (const mesh of [trunks, crowns]) {
      mesh.instanceMatrix.needsUpdate = true;
      mesh.frustumCulled = false;
      this.scene.add(mesh);
    }
  }

  /** Keeps the (small, sharp) shadow map centred on the aircraft. */
  followShadow(target: THREE.Vector3): void {
    // Snap the shadow frustum to whole shadow-map texels in light space, so shadows don't shimmer as we move.
    const dir = SUN_OFFSET.clone().normalize();
    const right = new THREE.Vector3(0, 1, 0).cross(dir).normalize();
    const upL = dir.clone().cross(right);
    const texel = 320 / 2048;
    const a = Math.round(target.dot(right) / texel) * texel;
    const b = Math.round(target.dot(upL) / texel) * texel;
    const c = Math.round(target.dot(dir) / texel) * texel;
    const snapped = right.multiplyScalar(a).add(upL.multiplyScalar(b)).add(dir.multiplyScalar(c));
    this.sun.target.position.copy(snapped);
    this.sun.position.copy(snapped).add(SUN_OFFSET);
    this.sun.target.updateMatrixWorld();
    for (const v of this.sunVisuals) v.position.copy(target).add(this.sunVisualOffset);
  }

  private onResize(): void {
    this.camera.aspect = window.innerWidth / window.innerHeight;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(window.innerWidth, window.innerHeight);
  }

  render(): void {
    this.renderer.render(this.scene, this.camera);
  }

  dispose(): void {
    window.removeEventListener('resize', this.resizeHandler);
    this.renderer.dispose();
    this.renderer.domElement.remove();
  }
}
