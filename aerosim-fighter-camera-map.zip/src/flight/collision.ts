import {
  AIRPORTS, CITY, CITY_BLOCKS, CITY_TOWERS, MOUNTAINS, MOUNTAIN_SIDES,
  airportStructures, airportToWorld, terrainHeight,
} from './world';

/**
 * Solid-world collision: city buildings, airport terminals/hangars, the
 * mountain cones and the rolling terrain. Pure maths on plain numbers (no
 * three.js objects) so it is cheap to call many times a frame — the aircraft
 * probes ~20 points on its airframe, and every piece of debris probes once.
 */

export type HitKind = 'building' | 'mountain' | 'terrain';

export interface WorldHit {
  kind: HitKind;
  /** Unit normal of the surface that was hit, pointing out of the obstacle. */
  nx: number;
  ny: number;
  nz: number;
  /** How far inside the obstacle the probed point is, along the normal. */
  depth: number;
}

export const createHit = (): WorldHit => ({ kind: 'terrain', nx: 0, ny: 1, nz: 0, depth: 0 });

/**
 * Terrain only counts as solid where it has actually risen off the flat
 * airfield level, and with a little grace, so rolling along the runway or
 * the open ground never registers as a collision — the normal takeoff and
 * landing rules (touchdown speed, gear, etc.) still own that.
 */
const TERRAIN_MIN_HEIGHT = 0.5;
const TERRAIN_GRACE = 0.25;

interface Box {
  cx: number;
  cz: number;
  cos: number;
  sin: number;
  hw: number;
  hd: number;
  h: number;
  /** Radius of the circle around the footprint, for a cheap early-out. */
  reach: number;
}

const BOXES: Box[] = [];

function addBox(cx: number, cz: number, yaw: number, w: number, d: number, h: number): void {
  BOXES.push({
    cx, cz, cos: Math.cos(yaw), sin: Math.sin(yaw), hw: w / 2, hd: d / 2, h, reach: Math.hypot(w / 2, d / 2),
  });
}

for (const [x, z, w, d, h] of [...CITY_BLOCKS, ...CITY_TOWERS]) addBox(CITY.x + x, CITY.z + z, 0, w, d, h);
for (const airport of AIRPORTS) {
  for (const s of airportStructures(airport.full)) {
    const [wx, wz] = airportToWorld(airport, s.x, s.z);
    addBox(wx, wz, airport.yaw, s.w, s.d, s.h);
  }
}

const SIDE = (Math.PI * 2) / MOUNTAIN_SIDES;
const APOTHEM = Math.cos(Math.PI / MOUNTAIN_SIDES);

/**
 * Tests a world-space point against every solid. Returns true (and fills
 * `hit`) if it is inside one. `margin` fattens buildings and the ground, which
 * is how debris chunks get a bit of body instead of being infinitely small.
 */
export function queryWorld(x: number, y: number, z: number, hit: WorldHit, margin = 0): boolean {
  // Buildings (oriented boxes standing on the ground).
  for (const b of BOXES) {
    const dx = x - b.cx;
    const dz = z - b.cz;
    const reach = b.reach + margin;
    if (dx * dx + dz * dz > reach * reach || y > b.h + margin) continue;
    const lx = dx * b.cos - dz * b.sin;
    const lz = dx * b.sin + dz * b.cos;
    const px = b.hw + margin - Math.abs(lx);
    const pz = b.hd + margin - Math.abs(lz);
    const py = b.h + margin - y;
    if (px <= 0 || pz <= 0 || py <= 0) continue;

    hit.kind = 'building';
    if (py <= px && py <= pz) {
      hit.nx = 0; hit.ny = 1; hit.nz = 0; hit.depth = py;
    } else if (px <= pz) {
      const s = lx < 0 ? -1 : 1;
      hit.nx = s * b.cos; hit.ny = 0; hit.nz = -s * b.sin; hit.depth = px;
    } else {
      const s = lz < 0 ? -1 : 1;
      hit.nx = s * b.sin; hit.ny = 0; hit.nz = s * b.cos; hit.depth = pz;
    }
    return true;
  }

  // Mountains (7-sided cones).
  for (const m of MOUNTAINS) {
    const apothem = m.radius * APOTHEM;
    const slope = Math.hypot(m.height, apothem);
    // Every face of a cone leans at the same angle, so a margin measured straight out from
    // the face is the same as raising the whole surface by margin * slope / apothem.
    const ye = y - (margin * slope) / apothem;
    const tip = m.centreY + m.height / 2;
    if (ye >= tip || ye <= tip - m.height) continue;
    const scale = (tip - ye) / m.height; // 0 at the summit, 1 at the base
    const reach = m.radius * scale;
    const dx = x - m.x;
    const dz = z - m.z;
    const dist = Math.hypot(dx, dz);
    if (dist >= reach) continue;
    // Which of the 7 flat faces is in this direction (corners sit at yaw + k*SIDE)?
    const bearing = Math.atan2(dx, dz);
    let rel = (bearing - m.yaw) % SIDE;
    if (rel < 0) rel += SIDE;
    if (dist >= (reach * APOTHEM) / Math.cos(rel - SIDE / 2)) continue;

    // Exact face plane: horizontal direction to the face's centre, and its slope.
    const faceAngle = bearing - rel + SIDE / 2;
    const ux = Math.sin(faceAngle);
    const uz = Math.cos(faceAngle);
    const gap = reach * APOTHEM - (dx * ux + dz * uz); // horizontal distance in from the face
    hit.kind = 'mountain';
    hit.nx = (ux * m.height) / slope;
    hit.ny = apothem / slope;
    hit.nz = (uz * m.height) / slope;
    hit.depth = (gap * m.height) / slope;
    return true;
  }

  // Rolling terrain.
  const ground = terrainHeight(x, z);
  if (ground > TERRAIN_MIN_HEIGHT && y < ground + margin - TERRAIN_GRACE) {
    const e = 4;
    const gx = (terrainHeight(x + e, z) - terrainHeight(x - e, z)) / (2 * e);
    const gz = (terrainHeight(x, z + e) - terrainHeight(x, z - e)) / (2 * e);
    const inv = 1 / Math.hypot(gx, 1, gz);
    hit.kind = 'terrain';
    hit.nx = -gx * inv; hit.ny = inv; hit.nz = -gz * inv;
    hit.depth = (ground + margin - TERRAIN_GRACE - y) * inv;
    return true;
  }

  return false;
}
