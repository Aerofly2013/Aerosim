import * as THREE from 'three';
import { AircraftType } from './types';
import { MODEL_GROUND_DROP } from './AircraftModel';

/**
 * A handful of points on the airframe, in aircraft-local coordinates (origin
 * at the controller's reference point, -Z forward, wheel contact at
 * y = -MODEL_GROUND_DROP). The aircraft crashes when any of them ends up
 * inside a building, mountain or hillside.
 *
 * The airliners are all scaled to ~35-36 units long, so only the wingspan, tail
 * height and engine layout differ between them.
 */
interface HullProfile {
  halfSpan: number;
  /** z of the wingtip — swept wings put the tips well aft of the root. */
  tipZ: number;
  finTop: number;
  bodyTop: number;
  bodyBottom: number;
  stabHalfSpan: number;
  engineXs: number[];
  length: number;
}

const PROFILES: Record<AircraftType, HullProfile> = {
  a350: { halfSpan: 17.4, tipZ: 6, finTop: 6.0, bodyTop: 1.2, bodyBottom: -1.8, stabHalfSpan: 6.5, engineXs: [-5.7, 5.7], length: 36 },
  a380: { halfSpan: 19.7, tipZ: 9, finTop: 8.5, bodyTop: 1.7, bodyBottom: -2.5, stabHalfSpan: 7.5, engineXs: [-12.5, -6.3, 6.3, 12.5], length: 36 },
  // Air Force One (VC-25, a 747-200B): measured from the converted model. bodyBottom is a little
  // more generous than the keel so rotation on take-off doesn't register as a belly strike.
  af1: { halfSpan: 15.5, tipZ: 7.6, finTop: 5.3, bodyTop: 1.6, bodyBottom: -2.4, stabHalfSpan: 5.0, engineXs: [-10.1, -5.7, 5.7, 10.1], length: 35 },
  f16: { halfSpan: 4.8, tipZ: 3, finTop: 3.1, bodyTop: 1.4, bodyBottom: -1.0, stabHalfSpan: 2.8, engineXs: [0], length: 15 },
};

export interface Hull {
  /** Always present: fuselage, tail, wings and engines. */
  body: THREE.Vector3[];
  /** The wheels — only part of the aircraft while the gear is down. */
  gear: THREE.Vector3[];
}

export function hullFor(type: AircraftType): Hull {
  const p = PROFILES[type];
  const LENGTH = p.length;
  const v = (x: number, y: number, z: number) => new THREE.Vector3(x, y, z);
  const body: THREE.Vector3[] = [
    // Nose and flight deck
    v(0, -0.5, -LENGTH / 2),
    v(0, p.bodyTop - 0.2, -LENGTH / 2 + 3),
    // Fuselage underside and spine
    v(0, p.bodyBottom, -9), v(0, p.bodyBottom, 0), v(0, p.bodyBottom, 9),
    v(0, p.bodyTop, -9), v(0, p.bodyTop, 0), v(0, p.bodyTop, 9),
    // Tail cone and fin
    v(0, 0.4, LENGTH / 2),
    v(0, p.finTop, LENGTH / 2 - 3),
    // Tailplane tips
    v(-p.stabHalfSpan, 0.7, LENGTH / 2 - 1.5), v(p.stabHalfSpan, 0.7, LENGTH / 2 - 1.5),
    // Mid-wing and wingtips
    v(-p.halfSpan / 2, 0.3, p.tipZ / 2), v(p.halfSpan / 2, 0.3, p.tipZ / 2),
    v(-p.halfSpan, 0.9, p.tipZ), v(p.halfSpan, 0.9, p.tipZ),
  ];
  for (const x of p.engineXs) body.push(v(x, -2.3, -3));

  const wheelY = -MODEL_GROUND_DROP;
  const gear = [v(0, wheelY, -14.8), v(-2.9, wheelY, 0.4), v(2.9, wheelY, 0.4)];
  return { body, gear };
}
