/**
 * Username validation + profanity filter.
 * Not perfect (no filter is), so names are also re-checked on every client
 * before being shown, and anything that fails is displayed as "PILOT".
 */

export const MAX_NAME = 16;
export const MIN_NAME = 3;

// Blocked if the word appears anywhere in the name (after normalising look-alike characters).
const BLOCKED_ANYWHERE = [
  'fuck', 'shit', 'bitch', 'cunt', 'nigger', 'nigga', 'faggot', 'retard', 'whore', 'slut', 'bastard',
  'pussy', 'penis', 'vagina', 'porn', 'rapist', 'nazi', 'hitler', 'kkk', 'pedophil', 'molest',
  'dildo', 'blowjob', 'handjob', 'masturbat', 'orgasm', 'cumshot', 'tranny', 'chink',
  'asshole', 'dumbass', 'jackass', 'bullshit', 'motherfuck', 'sperm', 'erection', 'boner',
  'genocide', 'holocaust', 'suicide', 'killyourself',
];

// Short or ambiguous words: only blocked when they are a whole word on their own
// (so "class", "cockpit" or "Dickens" are fine).
const BLOCKED_WHOLE_WORD = [
  'ass', 'sex', 'cum', 'tit', 'tits', 'dick', 'cock', 'anal', 'anus', 'fag', 'spic', 'kike',
  'coon', 'boob', 'boobs', 'rape', 'nude', 'nudes', 'hoe', 'milf', 'cumming', 'jizz', 'twat',
  'piss', 'crap', 'damn', 'wank', 'pedo', 'kys',
];

const LEET: Record<string, string> = {
  '0': 'o', '1': 'i', '3': 'e', '4': 'a', '5': 's', '7': 't', '8': 'b',
  '@': 'a', '$': 's', '!': 'i', '|': 'i', '+': 't', '€': 'e',
};

const collapse = (s: string) => s.replace(/(.)\1+/g, '$1');

function normalise(name: string): string {
  return name
    .toLowerCase()
    .split('')
    .map((c) => LEET[c] ?? c)
    .join('');
}

export function isInappropriate(name: string): boolean {
  const norm = normalise(name);
  const lettersOnly = norm.replace(/[^a-z]/g, '');
  const squashed = collapse(lettersOnly);

  for (const w of BLOCKED_ANYWHERE) {
    if (lettersOnly.includes(w)) return true;
    // Catch stretched spellings ("fuuuck") but only for longer words, so short ones don't over-match.
    const cw = collapse(w);
    if (cw.length >= 4 && squashed.includes(cw)) return true;
  }

  const tokens = norm.split(/[^a-z]+/).filter(Boolean);
  const candidates = new Set<string>([...tokens, lettersOnly]);
  for (const t of [...candidates]) candidates.add(collapse(t));
  for (const w of BLOCKED_WHOLE_WORD) {
    if (candidates.has(w) || candidates.has(collapse(w))) return true;
  }
  return false;
}

export function validateName(raw: string): { ok: true; name: string } | { ok: false; error: string } {
  const name = raw.trim().replace(/\s+/g, ' ');
  if (name.length < MIN_NAME) return { ok: false, error: `Username must be at least ${MIN_NAME} characters.` };
  if (name.length > MAX_NAME) return { ok: false, error: `Username must be ${MAX_NAME} characters or fewer.` };
  if (!/^[A-Za-z0-9_ -]+$/.test(name)) {
    return { ok: false, error: 'Use only letters, numbers, spaces, - and _.' };
  }
  if (!/[A-Za-z]/.test(name)) return { ok: false, error: 'Username must contain at least one letter.' };
  if (isInappropriate(name)) return { ok: false, error: 'That username isn\'t allowed. Please choose another.' };
  return { ok: true, name };
}

/** Name to show for other players: anything invalid or inappropriate becomes "PILOT". */
export function safeDisplayName(raw: unknown): string {
  if (typeof raw !== 'string') return 'PILOT';
  const r = validateName(raw);
  return r.ok ? r.name : 'PILOT';
}
