import * as THREE from 'three';

export type AircraftType = 'a350' | 'a380' | 'f16' | 'af1';

export const AIRCRAFT_TYPES: readonly AircraftType[] = ['a350', 'a380', 'f16', 'af1'];

/** Runtime check for values that arrive over the network and may come from another game version. */
export const isAircraftType = (v: unknown): v is AircraftType =>
  typeof v === 'string' && (AIRCRAFT_TYPES as readonly string[]).includes(v);

export interface AircraftState {
  position: THREE.Vector3;
  rotation: THREE.Euler;
  velocity: THREE.Vector3;
  throttle: number;
  pitch: number;
  roll: number;
  yaw: number;
  airspeed: number;
  verticalSpeed: number;
  angleOfAttack: number;
  stalled: boolean;
  flaps: number;       // 0..3 (0=clean, 1=takeoff, 2=approach, 3=full landing)
  gearDown: boolean;
  gearExtension: number; // 0 = fully retracted .. 1 = fully down and locked
  reverseThrust: boolean;    // reversers deployed (hold M)
  speedbrake: boolean;       // commanded: deployed or stowed
  speedbrakeExtension: number; // 0 = stowed .. 1 = fully deployed (animated)
  crashed: boolean;
  crashReason: string;
  onGround: boolean;
  heading: number;     // degrees
  bankAngle: number;   // degrees
  pitchAngle: number;  // degrees
}

export interface SimulationSettings {
  cameraMode: 'thirdPerson' | 'cockpit' | 'gear';
  mouseSensitivity: number;
  invertPitch: boolean;
}

export interface InputState {
  throttleUp: boolean;
  throttleDown: boolean;
  pitchUp: boolean;
  pitchDown: boolean;
  rollLeft: boolean;
  rollRight: boolean;
  yawLeft: boolean;
  yawRight: boolean;
  cameraToggle: boolean;
  reset: boolean;
  flapsUp: boolean;
  flapsDown: boolean;
  gearToggle: boolean;
  speedbrakeToggle: boolean;
  reverseThrust: boolean;
  fire: boolean;
}

export const defaultAircraftState = (spawn?: { x: number; z: number; yaw: number }): AircraftState => ({
  position: new THREE.Vector3(spawn?.x ?? 0, 3.5, spawn?.z ?? 600),
  rotation: new THREE.Euler(0, spawn?.yaw ?? 0, 0, 'YXZ'),
  velocity: new THREE.Vector3(0, 0, 0),
  throttle: 0,
  pitch: 0,
  roll: 0,
  yaw: 0,
  airspeed: 0,
  verticalSpeed: 0,
  angleOfAttack: 0,
  stalled: false,
  flaps: 0,
  gearDown: true,
  gearExtension: 1,
  reverseThrust: false,
  speedbrake: false,
  speedbrakeExtension: 0,
  crashed: false,
  crashReason: '',
  onGround: true,
  heading: 0,
  bankAngle: 0,
  pitchAngle: 0,
});

export const defaultSettings = (): SimulationSettings => ({
  cameraMode: 'thirdPerson',
  mouseSensitivity: 1,
  invertPitch: false,
});

export const FLAP_SETTINGS = [0, 15, 30, 45]; // degrees per flap setting
