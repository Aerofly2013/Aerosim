/**
 * Reverses the size-preserving packing applied to SIA_A350.pack.gz: vertex
 * positions and indices are delta + zig-zag coded and every buffer is split
 * into byte planes, which makes the file compress ~2x better than a plain GLB.
 */
export function unpackGlb(buf: ArrayBuffer): ArrayBuffer {
  const dv = new DataView(buf);
  const jsonLen = dv.getUint32(12, true);
  const json = JSON.parse(new TextDecoder().decode(new Uint8Array(buf, 20, jsonLen)));
  const binStart = 20 + jsonLen + 8;
  const bytes = new Uint8Array(buf);

  for (const bv of json.bufferViews as Array<{ byteOffset: number; byteLength: number; extras?: { pack?: string } }>) {
    const kind = bv.extras?.pack;
    if (!kind) continue;
    const off = binStart + bv.byteOffset;
    const src = bytes.slice(off, off + bv.byteLength); // packed copy
    const dst = bytes.subarray(off, off + bv.byteLength);

    if (kind === 'planes4') {
      const n = src.length / 4;
      for (let c = 0; c < 4; c++) for (let i = 0; i < n; i++) dst[i * 4 + c] = src[c * n + i];
    } else if (kind === 'pos') {
      const n = src.length / 8;
      const out = new Uint16Array(buf, off, n * 4);
      const acc = [0, 0, 0, 0];
      for (let i = 0; i < n; i++) {
        for (let c = 0; c < 4; c++) {
          const z = src[c * n + i] | (src[(4 + c) * n + i] << 8);
          acc[c] = (acc[c] + ((z >>> 1) ^ -(z & 1))) & 0xffff;
          out[i * 4 + c] = acc[c];
        }
      }
    } else if (kind === 'idx16') {
      const n = src.length / 2;
      const out = new Uint16Array(buf, off, n);
      let acc = 0;
      for (let i = 0; i < n; i++) {
        const z = src[i] | (src[n + i] << 8);
        acc = (acc + ((z >>> 1) ^ -(z & 1))) & 0xffff;
        out[i] = acc;
      }
    } else if (kind === 'idx32') {
      const n = src.length / 4;
      const out = new Uint32Array(buf, off, n);
      let acc = 0;
      for (let i = 0; i < n; i++) {
        const z = (src[i] | (src[n + i] << 8) | (src[2 * n + i] << 16) | (src[3 * n + i] << 24)) >>> 0;
        acc = (acc + ((z >>> 1) ^ -(z & 1))) | 0;
        out[i] = acc >>> 0;
      }
    }
  }
  return buf;
}
