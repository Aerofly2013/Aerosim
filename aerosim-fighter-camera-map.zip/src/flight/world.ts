// ---------------------------------------------------------------------------
// The archipelago.
//
// Islands are laid out like the reference chart: a main island (Greater
// Rockford) in the south-west with the other islands scattered around it.
// Positions are given in "chart pixels" of that image (W below) at 16 m per
// pixel, with Greater Rockford at the world origin.
// ---------------------------------------------------------------------------

const W = (px: number, py: number): { x: number; z: number } => ({ x: (px - 750) * 16, z: (py - 1365) * 16 });

export type PaletteName = 'green' | 'lush' | 'dry' | 'rock';

export interface Lobe {
  /** Offset of this blob from the island centre, and its half-extents, in metres. */
  dx: number;
  dz: number;
  rx: number;
  rz: number;
}

export interface IslandDef {
  name: string;
  x: number;
  z: number;
  lobes: Lobe[];
  palette: PaletteName;
  /** Height of the rolling hills inland (0 = pancake flat). */
  hills: number;
  /** How many mountain peaks to put on it. */
  peaks: number;
  seed: number;
}

export const ISLANDS: IslandDef[] = [
  { name: 'GREATER ROCKFORD', ...W(750, 1365), palette: 'green', hills: 110, peaks: 5, seed: 1.7,
    lobes: [{ dx: -100, dz: -1800, rx: 1700, rz: 1800 }, { dx: 250, dz: 1300, rx: 1600, rz: 1900 }] },
  { name: 'SAINT BARTHÉLEMY', ...W(895, 1015), palette: 'lush', hills: 60, peaks: 1, seed: 4.1,
    lobes: [{ dx: 0, dz: 0, rx: 1500, rz: 1250 }] },
  { name: 'GRINDAVIK', ...W(260, 925), palette: 'lush', hills: 70, peaks: 2, seed: 2.9,
    lobes: [{ dx: 800, dz: -100, rx: 1300, rz: 950 }, { dx: -800, dz: 150, rx: 1100, rz: 800 }] },
  { name: 'ORENJI', ...W(670, 470), palette: 'lush', hills: 80, peaks: 2, seed: 5.3,
    lobes: [{ dx: 100, dz: -900, rx: 1300, rz: 1000 }, { dx: -200, dz: 700, rx: 1200, rz: 1200 }] },
  { name: 'PERTH', ...W(1400, 690), palette: 'lush', hills: 90, peaks: 3, seed: 0.6,
    lobes: [{ dx: 0, dz: 0, rx: 1900, rz: 1400 }, { dx: 700, dz: -800, rx: 1000, rz: 900 }] },
  { name: 'IZOLIRANI', ...W(1600, 900), palette: 'dry', hills: 60, peaks: 2, seed: 3.3,
    lobes: [{ dx: -300, dz: 300, rx: 1900, rz: 1300 }, { dx: 900, dz: -500, rx: 900, rz: 1000 }] },
  { name: 'SKOPELOS', ...W(1390, 1165), palette: 'dry', hills: 50, peaks: 1, seed: 6.0,
    lobes: [{ dx: 0, dz: 0, rx: 1800, rz: 1500 }] },
  { name: 'CYPRUS', ...W(1470, 1690), palette: 'dry', hills: 50, peaks: 1, seed: 2.2,
    lobes: [{ dx: 0, dz: 0, rx: 1800, rz: 1100 }] },
  { name: 'SAUTHEMPTONA', ...W(190, 1405), palette: 'rock', hills: 120, peaks: 4, seed: 4.8,
    lobes: [{ dx: 0, dz: 0, rx: 1800, rz: 1500 }] },
];

export interface AirportDef {
  id: string;
  name: string;
  /** Which island it sits on. */
  island: string;
  x: number;
  z: number;
  /** Rotation about the vertical axis; the runway runs along local z. */
  yaw: number;
  runwayLength: number;
  /** The big airport has the full terminal, apron and hangars; the rest are small regional fields. */
  full: boolean;
}

export const AIRPORTS: AirportDef[] = [
  { id: 'A', name: 'ROCKFORD INTL', island: 'GREATER ROCKFORD', x: -350, z: 300, yaw: 0, runwayLength: 1500, full: true },
  { id: 'B', name: 'ST BARTHÉLEMY', island: 'SAINT BARTHÉLEMY', x: 2320, z: -5435, yaw: Math.PI / 2, runwayLength: 1250, full: false },
  { id: 'C', name: 'GRINDAVIK', island: 'GRINDAVIK', x: -7040, z: -6975, yaw: Math.PI / 2, runwayLength: 1200, full: false },
  { id: 'D', name: 'ORENJI', island: 'ORENJI', x: -1445, z: -14420, yaw: 0, runwayLength: 1200, full: false },
  { id: 'E', name: 'PERTH', island: 'PERTH', x: 10400, z: -10635, yaw: Math.PI / 2, runwayLength: 1300, full: false },
  { id: 'F', name: 'IZOLIRANI', island: 'IZOLIRANI', x: 13300, z: -6975, yaw: Math.PI / 2, runwayLength: 1200, full: false },
  { id: 'G', name: 'SKOPELOS', island: 'SKOPELOS', x: 10240, z: -3035, yaw: Math.PI / 2, runwayLength: 1200, full: false },
  { id: 'H', name: 'CYPRUS', island: 'CYPRUS', x: 11520, z: 5365, yaw: Math.PI / 2, runwayLength: 1200, full: false },
  { id: 'I', name: 'SAUTHEMPTONA', island: 'SAUTHEMPTONA', x: -9125, z: 640, yaw: 0, runwayLength: 1200, full: false },
];

/** A made-up city on the northern half of Greater Rockford, well clear of the airport. */
export const CITY = { name: 'MERIDIAN', x: -100, z: -1900, radius: 800 };

/** Converts a point in an airport's local frame to world x/z. */
export function airportToWorld(a: AirportDef, lx: number, lz: number): [number, number] {
  const c = Math.cos(a.yaw);
  const s = Math.sin(a.yaw);
  return [a.x + lx * c + lz * s, a.z - lx * s + lz * c];
}

/** Where the aircraft spawns for a given airport: partway down the runway, lined up for takeoff. */
export function spawnForAirport(a: AirportDef): { x: number; z: number; yaw: number } {
  const [x, z] = airportToWorld(a, 0, a.runwayLength / 2 - 150);
  return { x, z, yaw: a.yaw };
}

/** Converts a world point into an airport's local frame (inverse of airportToWorld). */
export function worldToAirport(a: AirportDef, x: number, z: number): [number, number] {
  const c = Math.cos(a.yaw);
  const s = Math.sin(a.yaw);
  const px = x - a.x;
  const pz = z - a.z;
  return [px * c - pz * s, px * s + pz * c];
}

/** Distance from a world point to the rectangle covering an airport's runway, apron and buildings. */
export function airportPadDistance(a: AirportDef, x: number, z: number): number {
  const [lx, lz] = worldToAirport(a, x, z);
  const dx = Math.max(-120 - lx, lx - (a.full ? 700 : 450), 0);
  const dz = Math.max(Math.abs(lz) - (a.runwayLength / 2 + 150), 0);
  return Math.hypot(dx, dz);
}

/** True inside the long thin strip under an airport's approach and departure paths. */
function inApproachCorridor(a: AirportDef, x: number, z: number, halfWidth: number, extra: number): boolean {
  const [lx, lz] = worldToAirport(a, x, z);
  return Math.abs(lx) < halfWidth && Math.abs(lz) < a.runwayLength / 2 + extra;
}

// ---------------------------------------------------------------------------
// Shared world geometry.
//
// Everything the player can fly into is defined here once, and used both by
// SceneManager (to draw it) and collision.ts (to crash into it), so what you
// see and what you hit can never drift apart.
// ---------------------------------------------------------------------------

export const smooth = (a: number, b: number, v: number) => {
  const t = Math.min(1, Math.max(0, (v - a) / (b - a)));
  return t * t * (3 - 2 * t);
};

const mix = (a: number, b: number, t: number) => a + (b - a) * t;

/** A tiny deterministic random generator, so the world is identical every run. */
function rng(seed: number): () => number {
  let s = Math.floor(seed * 1000) % 2147483647 || 1;
  return () => {
    s = (s * 48271) % 2147483647;
    return s / 2147483647;
  };
}

// --- Sea and terrain ---------------------------------------------------------

/** World y of the water surface. Land (and every runway) sits at y = 0, so the sea is just below it. */
export const SEA_LEVEL = -1.5;
const SEABED = -45;

export const TERRAIN_SIZE = 33000;
export const TERRAIN_SEGMENTS = 330;
/** The terrain square is centred over the archipelago rather than the origin. */
export const TERRAIN_CENTER_X = 2600;
export const TERRAIN_CENTER_Z = -5000;
const TERRAIN_CELL = TERRAIN_SIZE / TERRAIN_SEGMENTS;
const TERRAIN_HALF = TERRAIN_SIZE / 2;
const GRID_N = TERRAIN_SEGMENTS + 1;

/** How far inland a point is, as a fraction of the island's radius: > 0 is land, < 0 is sea. */
function islandMask(isl: IslandDef, x: number, z: number): number {
  const s = isl.seed;
  let best = -Infinity;
  for (const l of isl.lobes) {
    const dx = (x - isl.x - l.dx) / l.rx;
    const dz = (z - isl.z - l.dz) / l.rz;
    const a = Math.atan2(dz, dx);
    // A wobbly coastline: a few lumps around the shore plus a slow drift across the map.
    const n = 1 + 0.11 * Math.sin(3 * a + s) + 0.07 * Math.sin(5 * a + s * 2.3) + 0.04 * Math.sin(9 * a + s * 0.7)
      + 0.06 * Math.sin(x * 0.0011 + s) * Math.cos(z * 0.0013 - s);
    best = Math.max(best, 1 - Math.hypot(dx, dz) / n);
  }
  // Every airport and the city are guaranteed dry land, whatever the coastline does.
  for (const a of AIRPORTS) {
    if (a.island !== isl.name) continue;
    const boost = 0.22 * (1 - smooth(120, 420, airportPadDistance(a, x, z)));
    if (boost > 0) best = Math.max(best, boost);
  }
  if (isl.name === 'GREATER ROCKFORD') {
    const boost = 0.22 * (1 - smooth(CITY.radius, CITY.radius + 300, Math.hypot(x - CITY.x, z - CITY.z)));
    if (boost > 0) best = Math.max(best, boost);
  }
  return best;
}

interface LandSample {
  m: number;
  island: number;
}

function sampleLand(x: number, z: number): LandSample {
  let m = -Infinity;
  let island = 0;
  for (let i = 0; i < ISLANDS.length; i++) {
    const v = islandMask(ISLANDS[i], x, z);
    if (v > m) { m = v; island = i; }
  }
  return { m, island };
}

/** 0 right beside an airport or the city, easing up to 1 further out — hills only rise away from them. */
function flatten(x: number, z: number): number {
  let f = smooth(CITY.radius, CITY.radius + 500, Math.hypot(x - CITY.x, z - CITY.z));
  for (const a of AIRPORTS) f = Math.min(f, smooth(350, 1300, airportPadDistance(a, x, z)));
  return f;
}

function terrainFormula(x: number, z: number, land: LandSample): number {
  const { m, island } = land;
  if (m <= 0) {
    // Sea floor: a shallow shelf around each island that drops away.
    return -3 + (SEABED + 3) * smooth(0, 0.6, -m);
  }
  const isl = ISLANDS[island];
  const s = isl.seed;
  const beach = -3 + 3 * smooth(0, 0.1, m);
  const noise = Math.max(0,
    Math.sin(x * 0.0021 + s) * Math.cos(z * 0.0018 + s * 0.5) * 0.8 +
    Math.sin((x + z) * 0.004 + s) * 0.33,
  );
  return beach + noise * isl.hills * smooth(0.3, 0.8, m) * flatten(x, z);
}

type RGB = [number, number, number];
const hex = (v: number): RGB => [((v >> 16) & 255) / 255, ((v >> 8) & 255) / 255, (v & 255) / 255];
const mixRGB = (a: RGB, b: RGB, t: number): RGB => [mix(a[0], b[0], t), mix(a[1], b[1], t), mix(a[2], b[2], t)];

const PALETTES: Record<PaletteName, { low: RGB; mid: RGB; high: RGB }> = {
  green: { low: hex(0x4a7a43), mid: hex(0x3b633b), high: hex(0x7a7466) },
  lush: { low: hex(0x3f7a45), mid: hex(0x2f6338), high: hex(0x6d7260) },
  dry: { low: hex(0x9a9a58), mid: hex(0x7d8a4f), high: hex(0x93846a) },
  rock: { low: hex(0x8a8d86), mid: hex(0x9a9d98), high: hex(0xe8eced) },
};
const SAND = hex(0xdccb9a);
const SHALLOW = hex(0x7fd0c0);
const MID_SEA = hex(0x2b88a2);
const DEEP_SEA = hex(0x0c3550);

function terrainColor(h: number, land: LandSample, x: number, z: number): RGB {
  // A little deterministic speckle so the low-poly facets read.
  const jitter = 0.94 + 0.12 * (Math.abs(Math.sin(x * 12.9898 + z * 78.233) * 43758.5453) % 1);
  let c: RGB;
  if (land.m <= 0) {
    const depth = -h;
    c = mixRGB(mixRGB(SHALLOW, MID_SEA, smooth(1.5, 10, depth)), DEEP_SEA, smooth(10, 45, depth));
  } else {
    const pal = PALETTES[ISLANDS[land.island].palette];
    const grass = mixRGB(mixRGB(pal.low, pal.mid, smooth(1, 40, h)), pal.high, smooth(60, 150, h));
    c = mixRGB(SAND, grass, smooth(0.08, 0.2, land.m));
  }
  return [c[0] * jitter, c[1] * jitter, c[2] * jitter];
}

/**
 * Terrain heights at the vertices of the PlaneGeometry, in the same order
 * three.js lays them out (row by row), plus a matching colour per vertex.
 * SceneManager copies these onto the mesh, and terrainHeight() interpolates
 * them the same way the GPU does.
 */
export const { TERRAIN_HEIGHTS, TERRAIN_COLORS } = (() => {
  const heights = new Float32Array(GRID_N * GRID_N);
  const colors = new Float32Array(GRID_N * GRID_N * 3);
  for (let iy = 0; iy < GRID_N; iy++) {
    for (let ix = 0; ix < GRID_N; ix++) {
      const x = ix * TERRAIN_CELL - TERRAIN_HALF + TERRAIN_CENTER_X;
      const z = iy * TERRAIN_CELL - TERRAIN_HALF + TERRAIN_CENTER_Z;
      const land = sampleLand(x, z);
      const h = terrainFormula(x, z, land);
      const i = iy * GRID_N + ix;
      heights[i] = h;
      const [r, g, b] = terrainColor(h, land, x, z);
      colors[i * 3] = r; colors[i * 3 + 1] = g; colors[i * 3 + 2] = b;
    }
  }
  return { TERRAIN_HEIGHTS: heights, TERRAIN_COLORS: colors };
})();

/** Ground height at a world x/z, matching the rendered mesh triangle for triangle. Open sea beyond the map. */
export function terrainHeight(x: number, z: number): number {
  const fx = (x - TERRAIN_CENTER_X + TERRAIN_HALF) / TERRAIN_CELL;
  const fz = (z - TERRAIN_CENTER_Z + TERRAIN_HALF) / TERRAIN_CELL;
  if (!(fx >= 0 && fz >= 0 && fx < TERRAIN_SEGMENTS && fz < TERRAIN_SEGMENTS)) return SEABED;
  const ix = Math.floor(fx);
  const iy = Math.floor(fz);
  const u = fx - ix;
  const v = fz - iy;
  const a = TERRAIN_HEIGHTS[iy * GRID_N + ix];
  const b = TERRAIN_HEIGHTS[(iy + 1) * GRID_N + ix];
  const c = TERRAIN_HEIGHTS[(iy + 1) * GRID_N + ix + 1];
  const d = TERRAIN_HEIGHTS[iy * GRID_N + ix + 1];
  // PlaneGeometry splits each cell along the b-d diagonal into (a,b,d) and (b,c,d).
  return u + v <= 1 ? a + u * (d - a) + v * (b - a) : c + (1 - u) * (b - c) + (1 - v) * (d - c);
}

/** True where the ground is below the water surface — touching down here is a ditching. */
export function isWater(x: number, z: number): boolean {
  return terrainHeight(x, z) < SEA_LEVEL;
}

// --- Mountains -------------------------------------------------------------

export const MOUNTAIN_SIDES = 7;

export interface MountainDef {
  x: number;
  z: number;
  /** Circumradius of the base (the cone's corners). */
  radius: number;
  height: number;
  /** World y of the cone's middle; it spans centreY +- height/2. */
  centreY: number;
  yaw: number;
}

/** Scatters each island's peaks well inland, clear of runways, their approach paths and the city. */
export const MOUNTAINS: MountainDef[] = (() => {
  const out: MountainDef[] = [];
  ISLANDS.forEach((isl, idx) => {
    const rand = rng(isl.seed * 7.7 + 1);
    let placed = 0;
    for (let tries = 0; tries < 1200 && placed < isl.peaks; tries++) {
      const lobe = isl.lobes[Math.floor(rand() * isl.lobes.length)];
      const x = isl.x + lobe.dx + (rand() * 2 - 1) * lobe.rx * 0.8;
      const z = isl.z + lobe.dz + (rand() * 2 - 1) * lobe.rz * 0.8;
      const radius = 180 + rand() * 120;
      const height = 260 + rand() * 260;
      const land = sampleLand(x, z);
      if (land.island !== idx || land.m < 0.3) continue;
      if (AIRPORTS.some((a) => airportPadDistance(a, x, z) < 600 + radius)) continue;
      if (AIRPORTS.some((a) => inApproachCorridor(a, x, z, 250 + radius, 2000))) continue;
      if (Math.hypot(x - CITY.x, z - CITY.z) < CITY.radius + radius + 150) continue;
      if (out.some((o) => Math.hypot(o.x - x, o.z - z) < o.radius + radius + 100)) continue;
      out.push({ x, z, radius, height, centreY: height / 2 - 30, yaw: rand() * 6 });
      placed++;
    }
  });
  return out;
})();

// --- Trees -------------------------------------------------------------------

/** [x, z, variant] for every tree, scattered over dry land and kept off runways and their approaches. */
export const TREES: Array<[number, number, number]> = (() => {
  const out: Array<[number, number, number]> = [];
  ISLANDS.forEach((isl, idx) => {
    const rand = rng(isl.seed * 3.3 + 2);
    const area = isl.lobes.reduce((sum, l) => sum + l.rx * l.rz, 0);
    const attempts = Math.round(area / 5200);
    for (let n = 0; n < attempts; n++) {
      const lobe = isl.lobes[Math.floor(rand() * isl.lobes.length)];
      const x = isl.x + lobe.dx + (rand() * 2 - 1) * lobe.rx;
      const z = isl.z + lobe.dz + (rand() * 2 - 1) * lobe.rz;
      const variant = Math.floor(rand() * 20);
      const land = sampleLand(x, z);
      if (land.island !== idx || land.m < 0.18) continue;
      if (isl.palette === 'rock' && terrainHeight(x, z) > 40) continue;
      if (AIRPORTS.some((a) => airportPadDistance(a, x, z) < 450 || inApproachCorridor(a, x, z, 170, 1800))) continue;
      if (Math.hypot(x - CITY.x, z - CITY.z) < CITY.radius + 100) continue;
      out.push([x, z, variant]);
    }
  });
  return out;
})();

// --- City ------------------------------------------------------------------

/** [x, z, width, depth, height] in the city's local frame (origin at CITY.x/CITY.z). */
export type CityBox = [number, number, number, number, number];

function buildCityLayout(): { blocks: CityBox[]; towers: CityBox[] } {
  const blocks: CityBox[] = [];
  const towers: CityBox[] = [];
  for (let gx = -3; gx <= 3; gx++) {
    for (let gz = -3; gz <= 3; gz++) {
      const cx = gx * 180, cz = gz * 180;
      const distFromCentre = Math.hypot(gx, gz);
      if (distFromCentre < 0.4) continue; // leave the central plaza open
      const seed = (gx * 13 + gz * 7 + 100);
      const slots: Array<[number, number]> = [[-45, -45], [45, -45], [-45, 45], [45, 45]];
      slots.forEach(([ox, oz], k) => {
        const s = ((seed * 31 + k * 17) % 100) / 100;
        const h = 18 + s * (distFromCentre < 1.6 ? 170 : 55);
        const w = 30 + ((seed + k) % 3) * 6;
        const list = h > 90 ? towers : blocks;
        list.push([cx + ox, cz + oz, w, w, h]);
      });
    }
  }
  return { blocks, towers };
}

const CITY_LAYOUT = buildCityLayout();
export const CITY_BLOCKS: CityBox[] = CITY_LAYOUT.blocks;
export const CITY_TOWERS: CityBox[] = CITY_LAYOUT.towers;

// --- Airport buildings -----------------------------------------------------

export interface StructureDef {
  kind: 'terminal' | 'hangar';
  /** Centre in the airport's local frame, plus footprint and height. */
  x: number;
  z: number;
  w: number;
  d: number;
  h: number;
}

/** Terminal and hangars for the main field (`full`) or a small regional one. */
export function airportStructures(full: boolean): StructureDef[] {
  if (full) {
    return [
      { kind: 'terminal', x: 300, z: 520, w: 320, d: 75, h: 34 },
      ...[100, 250, 400, 550].map((x): StructureDef => ({ kind: 'hangar', x, z: -320, w: 95, d: 100, h: 28 })),
    ];
  }
  return [
    { kind: 'terminal', x: 200, z: 260, w: 140, d: 50, h: 28 },
    ...[130, 270].map((x): StructureDef => ({ kind: 'hangar', x, z: -100, w: 80, d: 70, h: 24 })),
  ];
}
